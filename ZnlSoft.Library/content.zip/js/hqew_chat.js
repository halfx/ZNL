﻿//弹出窗
var popWp,
    popShow = function (obt) {
        if (!popWp) {
            popWp = Q('<div id=\"g-popup\"><div class=\"g-popup-mask\"><iframe frameborder=\"0\" scrolling=\"no\"></iframe></div><table class=\"g-popup-box\"><tbody><tr><td></td></tr></tbody></table></div>').appendTo('body').find('td');
            if (obt.elt) {
                Q(obt.elt).show();
                popWp.append(obt.elt);
            } else if (obt.html) {
                popWp.html(obt.html);
            }
            if (obt.callback) {
                obt.callback();
            }
            Q(obt.hide).click(function () {
                popHide();
            });
            window.popHide = function () {
                if (obt.elt) {
                    Q(obt.elt).hide();
                    Q('body').append(obt.elt);
                }
                if (popWp) {
                    popWp.end().remove();
                    popWp = null;
                }
            };
        }
    },

//web洽洽
    webQQ = {
        //初始化
        init: function () {
            webQQ.contactData = [];
            webQQ.isRead = [];
            webQQ.readData = {};
            webQQ.unreadData = {};
            webQQ.saveChatNewTimer = null;
            webQQ.getChatNewTimer = null;
            webQQ.uid = 0;
            webQQ.euid = 0;
            webQQ.cname = '';
            webQQ.kname = '';
            webQQ.status = 0;
            webQQ.service = 0;
            webQQ.iuid = 0;
            webQQ.ieuid = 0;
            webQQ.icname = '';
            webQQ.ikname = '系统提示';
            webQQ.lid = 0;
            webQQ.webqq_chat_con = Q('#webqq_chat_con');
            webQQ.webqq_list_con = Q('#webqq_list_con');
            webQQ.webqq_state_ico = Q('#webqq_state_ico');
            webQQ.webqq_state = Q('#webqq_state');
            webQQ.webqq_chat_text = Q('#webqq_chat_text');
            webQQ.webqq_chat = Q('#webqq_chat');
            webQQ.webqq_state_tip = Q('#webqq_state_tip');
            webQQ.webqq_state.click(function () {
                webQQ.webqq_state.hasClass('cur') ? webQQ.close() : webQQ.getContact(true);
            });

            Q('#webqq_list_close').on('click', function () {
                webQQ.close();
                webQQ.hasUnread();
            });
            Q('#webqq_chat_close').on('click', function () {
                clearTimeout(webQQ.getChatNewTimer);
                webQQ.webqq_chat.hide();
                webQQ.uid = 0;
                webQQ.euid = 0;
                webQQ.cname = '';
                webQQ.kname = '';
            });

            var postMsg = function () {
                var msg = webQQ.webqq_chat_text.val().trim();
                if (msg == '') {
                } else {
                    if (msg.len() > 200) {
                        alert('信息不能超过200个字符');
                    } else {
                        webQQ.postChat(msg);
                    }
                }
                webQQ.webqq_chat_text.e[0].focus();
            };

            Q('#webqq_chat_send').on('click', postMsg);
            Q('#webqq_chat_form').on('keydown', function (e) {
                ((e.ctrlKey && e.keyCode == 13) || (e.altKey && e.keyCode == 83)) && postMsg();
            });

            var chatX, chatY, chatM = false;
            Q('#webqq_chat_bar').mousedown(function (e) {
                chatM = true;
                chatX = e.pageX - webQQ.webqq_chat.e[0].offsetLeft;
                chatY = e.pageY - webQQ.webqq_chat.e[0].offsetTop;
            });

            Q(document)
                .mousemove(function (e) {
                    if (chatM) {
                        var x = e.pageX - chatX,
                            y = e.pageY - chatY;
                        window.getSelection ? window.getSelection().removeAllRanges() : this.selection.empty();
                        webQQ.webqq_chat.style({
                            'left': x + 'px',
                            'top': y + 'px',
                            'marginLeft': 0,
                            'marginTop': 0
                        });
                    }
                }).mouseup(function () {
                    chatM = false;
                });
        },
        close: function () {
            Q('#webqq_list, #webqq_list_con, #quote_list_con, #inquire_list_con').hide();
            Q('#webqq_state, #quote_state, #inquire_express').css('over', '').css('cur', '');
        },
        //创建ajax链接
        createConnection: function (sparam, callback) {
            Q.ajax({
                url: '/chat/chat.aspx',
                type: 'json',
                start: function () { },
                stop: function () { },
                param: sparam,
                success: function (result) {
                    if (result == null) {
                        clearTimeout(webQQ.getChatNewTimer);
                        clearTimeout(webQQ.saveChatNewTimer);
                        webQQ.webqq_state_ico
                            .css('qqon', 'qqoff')
                            .css('qqmsg', 'qqoff');
                        login.show(function () {
                            webQQ.getChat();
                            webQQ.getChatNew();
                        });
                        return false;
                    } else {
                        callback(result);
                    }
                    return true;
                }
            });
        },
        //发送消息
        postChat: function (messageBody) {
            webQQ.createConnection('act=chat&tid=' + webQQ.uid + '&msg=' + messageBody, function (result) {
                messageBody = messageBody.encodeHtml();
                var msg = [
                    {
                        'FromUserID': webQQ.iuid,
                        'FromEntUserID': webQQ.ieuid,
                        'FromCompanyName': '',
                        'FromNickName': result.Succ ? result.DisplayName : webQQ.ikname,
                        'ToUserID': webQQ.uid,
                        'ToEntUserID': webQQ.euid,
                        'ToCompanyName': webQQ.cname,
                        'ToNickName': webQQ.kname,
                        'MessageType': 1,
                        'MessageBody': result.Succ ? messageBody : messageBody + '<span style=\"margin-left:10px; color:#999\">消息发送失败</span><span style=\"display:none;\">' + result.DisplayName + '</span>',
                        'SendTime': result.Time
                    }
                ];
                webQQ.appendChat(msg);
                webQQ.readData[webQQ.uid] = webQQ.readData[webQQ.uid].concat(msg);
                webQQ.webqq_chat_text.val('');
                webQQ.webqq_list_con.prepend('#u' + webQQ.uid);
            });
        },
        //新消息推送缓存
        saveChatNew: function () {
            webQQ.createConnection('act=msg&lid=' + webQQ.lid + '&isread=' + webQQ.isRead, function (result) {
                webQQ.isRead = [];
                Q.each(result, function () {
                    if (this.MessageID > webQQ.lid) {
                        webQQ.lid = this.MessageID;
                    }
                    webQQ.appendContact([
                        {
                            'UserID': this.FromUserID,
                            'EntUserID': this.FromEntUserID,
                            'CompanyName': this.FromCompanyName,
                            'NickName': this.FromNickName,
                            'UserStatus': 1,
                            'IsService': this.FromIsService
                        }
                    ]);
                    webQQ.unreadData[this.FromUserID] = webQQ.unreadData[this.FromUserID].concat(this);
                    if (webQQ.uid != this.FromUserID) {
                        Q('#n' + this.FromUserID).text('(' + webQQ.unreadData[this.FromUserID].length + ')');
                        //Q('#u' + this.FromUserID).css('new')
                    }
                });
            });
            webQQ.hasUnread();
            webQQ.saveChatNewTimer = setTimeout(arguments.callee, 5000);
        },
        //未读消息
        hasUnread: function () {
            var flag = false,
                unreadCount = 0;
            Q.each(webQQ.unreadData, function () {
                if (this.length != 0) {
                    flag = true;
                }
                unreadCount += this.length;
            });
            if (flag && !webQQ.webqq_state.hasClass('cur')) {
                webQQ.webqq_state_ico.css('qqon', 'qqmsg');
                webQQ.webqq_state_tip.show().html('有' + (unreadCount > 99 ? 'N' : unreadCount) + '条新消息<u></u>');
            } else if (flag && webQQ.webqq_state.hasClass('cur')) {
                webQQ.webqq_state_ico.css('qqmsg', 'qqon');
                webQQ.webqq_state_tip.hide();
            }
        },
        //添加聊天记录
        appendChat: function (chatList, read) {
            var emote = function (str) {
                var re = /\[\/emote([0-9]+)\]/ig;
                var newstr = str.replace(re, '<img src=\"http://www.hqewimg.com/images/hqm/hqmemotes/$1.gif\">');
                var re2 = /\[\/yglemote:(.*?)\]/ig;
                newstr = newstr.replace(re2, '');
                newstr == '' && (newstr = '<span style=\"color:#999\">网页版洽洽不支持自定义图片显示</span>');
                return newstr;
            };
            Q.each(chatList, function () {
                var msg = '', packet;
                if (this.MessageType == 1) {
                    msg = emote(this.MessageBody);
                } else if (this.MessageType == 4) {
                    packet = Q.eval(this.MessageBody);
                    if (this.FromUserID == webQQ.uid) {
                        msg += '<span style=\"color:#666\">收到' + this.FromNickName + '对' + packet.PModel + '的询价，请使用<a href=\"http://im.hqew.com/2012.html\" target=\"_blank\">洽洽客户端</a>查看。</span>';
                    } else {
                        msg += '<span style=\"color:#666\">你对' + this.ToNickName + '发起一个询价</span>';
                        msg += '<table>';
                        msg += '<tr><th>型号</th><th>厂商</th><th>封装</th><th>批号</th><th>数量</th></tr>';
                        msg += '<tr><td>' + packet.PModel + '</td><td>' + packet.PProductor + '</td><td>' + packet.PPackage + '</td><td>' + packet.PProductDate + '</td><td>' + packet.PQuantity + '</td></tr>';
                        msg += '<tr><td colspan=\"5\">' + packet.PRemark + '</td></tr>';
                        msg += '</table>';
                    }
                } else if (this.MessageType == 5) {
                    packet = Q.eval(this.MessageBody);
                    if (this.FromUserID == webQQ.uid) {
                        msg += '<span style=\"color:#666\">收到' + this.FromNickName + '的报价</span>';
                    } else {
                        msg += '<span style=\"color:#666\">发给' + this.ToNickName + '的报价</span>';
                    }
                    msg += '<table>';
                    msg += '<tr><th>型号</th><th>厂商</th><th>封装</th><th>批号</th><th>数量</th></tr>';
                    msg += '<tr><td>' + packet.PModel + '</td><td>' + packet.PProductor + '</td><td>' + packet.PPackage + '</td><td>' + packet.PProductDate + '</td><td>' + packet.PQuantity + '</td></tr>';
                    msg += '<tr><td colspan=\"5\">' + packet.PRemark + '</td></tr>';
                    msg += '<tr><td colspan=\"5\"><b style="color:#f60">报价：' + packet.QuotePrice + '</b></td></tr>';
                    msg += '</table>';
                }
                webQQ.webqq_chat_con.append('<div class=\"con\"><p class=\"' + (this.FromUserID == webQQ.uid ? 'from' : 'to') + '\"><span>' + this.FromNickName + '</span><span>' + this.SendTime + '</span></p><div class=\"msg\">' + msg + '</div></div>');
                webQQ.webqq_chat_con.e[0].scrollTop = webQQ.webqq_chat_con.e[0].scrollHeight;
                this.MessageID && read && webQQ.isRead.push(this.MessageID);
            });
        },
        //获取新消息
        getChatNew: function () {
            if (webQQ.uid != 0) {
                Q('#n' + webQQ.uid).html('');
                //Q('#u' + webQQ.uid).css('new', '');
                webQQ.appendChat(webQQ.unreadData[webQQ.uid], true);
                webQQ.readData[webQQ.uid] = webQQ.readData[webQQ.uid].concat(webQQ.unreadData[webQQ.uid]);
                webQQ.unreadData[webQQ.uid] = [];
            }
            webQQ.getChatNewTimer = setTimeout(arguments.callee, 1000);
        },
        //获取历史记录
        getChat: function () {
            if (webQQ.uid != 0) {
                if (webQQ.readData[webQQ.uid].length > 0) {
                    webQQ.appendChat(webQQ.readData[webQQ.uid]);
                } else {
                    webQQ.createConnection('act=history&tid=' + webQQ.uid, function (result) {
                        if (Q.type(result) == 'array') {
                            webQQ.appendChat(result);
                            webQQ.readData[webQQ.uid] = webQQ.readData[webQQ.uid].concat(result);
                        } else {
                            webQQ.appendChat([
                                {
                                    'FromUserID': webQQ.uid,
                                    'FromEntUserID': webQQ.euid,
                                    'FromCompanyName': webQQ.cname,
                                    'FromNickName': webQQ.kname,
                                    'MessageType': 1,
                                    'MessageBody': '您好，请问有什么可以帮助您的吗？',
                                    'SendTime': result
                                }
                            ]);
                        }
                    });
                }
            }
        },
        //打开聊天窗
        openChatDialog: function (uid, euid, cname, kname, status, service) {
            webQQ.webqq_chat_con.empty();
            webQQ.webqq_chat.show();
            webQQ.webqq_chat_text.e[0].focus();
            Q('#webqq_chat_name').html((cname ? ('<b title=\"' + cname + '\">' + (cname.len() > 32 ? cname.cut(32) + '...' : cname) + '</b> - ') : '') + '<span title=\"' + kname + '\">' + (kname.len() > 12 ? kname.cut(12) + '...' : kname) + '</span>');
            Q('#webqq_chat_status').text(status > 0 ? '[在线]' : '[离线]');
            webQQ.uid = uid;
            webQQ.euid = euid;
            webQQ.cname = cname;
            webQQ.kname = kname;
            webQQ.status = status;
            webQQ.service = service;
            webQQ.getChat();
            clearTimeout(webQQ.getChatNewTimer);
            webQQ.getChatNew();
        },
        //添加联系人
        appendContact: function (contactList) {
            if (contactList.length > 0) {
                var hasService = function (uid, euid, service) {
                    var flag = 0;
                    Q.each(webQQ.contactData, function () {
                        if (service == 1) {
                            if (this.IsService == 1) {
                                if (this.EntUserID == euid) {
                                    if (this.UserID == uid) {
                                        flag = 1;
                                        return false;
                                    } else {
                                        flag = this.UserID;
                                        webQQ.contactData.remove(this);
                                        return false;
                                    }
                                }
                            }
                        } else {
                            if (this.UserID == uid) {
                                flag = 1;
                                return false;
                            }
                        }
                        return true;
                    });
                    return flag;
                },
                    hasUid = function (uid) {
                        var flag = 0;
                        Q.each(webQQ.contactData, function () {
                            if (this.UserID == uid) {
                                flag = 1;
                            }
                        });
                        return flag;
                    };

                Q.each(contactList, function () {
                    var self = this,
                        title = self.NickName + (self.CompanyName ? ' - ' + self.CompanyName : ''),
                        currentService = hasService(self.UserID, self.EntUserID, self.IsService),
                        currentUid = hasUid(self.UserID),

                        add = function (e) {
                            webQQ.webqq_list_con.prepend(e);
                            Q(e)
                                .html('<span id=\"n' + self.UserID + '\"></span>' + self.NickName).css(self.UserStatus == 0 ? (self.Gender == 1 ? 'maleoff' : 'femaleoff') : (self.Gender == 1 ? 'male' : 'female')).attr({
                                    id: 'u' + self.UserID,
                                    eid: 'u' + self.EntUserID,
                                    ser: self.IsService,
                                    title: title,
                                    href: 'javascript:;'
                                })
                                .on('click', function () {
                                    if (HQMCheck()) {
                                        if (self.IsService == 1) {
                                            HqmService(self.UserID, '6149505f-c4fe-4b07-ae47-175069ff25e1', 1, self.EntUserID, 0);
                                        } else {
                                            HqmChat(self.UserID, '6149505f-c4fe-4b07-ae47-175069ff25e1', '');
                                        }
                                    } else {
                                        webQQ.openChatDialog(self.UserID, self.EntUserID, self.CompanyName, self.NickName, self.UserStatus, self.IsService);
                                    }
                                })
                                .on('mouseover', function () {
                                    var tag = Q(this);
                                    if (self.Info) {
                                        webqqCard.show(self.Info);
                                        webqqCard.div.show().style({
                                            'top': (tag.position(false).top + webqqCard.div.offset().height > document.documentElement.clientHeight ? tag.position(true).top - webqqCard.div.offset().height + tag.offset().height + 11 : tag.position(true).top - 1) + 'px',
                                            'left': Q('#webqq_list').position(true).left - 251 + 'px'
                                        });
                                    }
                                })
                                .on('mouseout', function () {
                                    webqqCard.div.hide();
                                });
                            webQQ.readData[self.UserID] = [];
                            webQQ.unreadData[self.UserID] = [];
                            webQQ.contactData.push(self);
                        };

                    if (currentUid == 0) {
                        add(document.createElement('a'));
                    } else if (currentUid == 1) {
                        webQQ.webqq_list_con.prepend('#u' + self.UserID);
                    } else {
                        add('#u' + currentService);
                    }
                });
            } else {
                Q('#webqq_list_con').html('<ul class=\"empty\"><li><b></b><span><i class=\"g-d-ib g-fs-n\">点击</i><i class=\"eqq1 g-mlr-5 g-mt-5\"></i><i class=\"g-d-ib g-fs-n\">图标洽谈</i></span></li><li class=\"arr\"></li><li><b></b><span>对方将出现在这里</span></li></ul>');
            }
        },
        //获取联系人
        getContact: function (show) {
            webQQ.createConnection('act=lastlink', function (result) {
                if (show) {
                    webQQ.close();
                    webQQ.webqq_state.css('cur');
                    Q('#webqq_list').style({
                        right: '0px'
                    });
                    Q('#webqq_list_bar').text('最近联系人');
                    Q('#webqq_list, #webqq_list_con').show();
                }
                webQQ.appendContact(result);
                if (webQQ.uid != 0) {
                    webQQ.appendContact([
                        {
                            'UserID': webQQ.uid,
                            'EntUserID': webQQ.euid,
                            'CompanyName': webQQ.cname,
                            'NickName': webQQ.kname,
                            'UserStatus': webQQ.status,
                            'IsService': 1
                        }
                    ]);
                }
                clearTimeout(webQQ.saveChatNewTimer);
                webQQ.saveChatNew();
                webQQ.webqq_state_ico.css('qqoff', 'qqon');
                //Q('#stateTipLog').hide()
            });
        },
        //打开聊天窗
        openChatDialogNew: function (euid, eguid, status, inquire) {
            if (HQMCheck()) {
                HqmService(euid, eguid, 1, euid, 0, inquire);
            } else {
                Q.js({
                    url: 'http://hqmim.hqew.com/ajax/services.aspx?uid=' + euid + '&ug=' + eguid + '&type=1&entuid=' + euid + '&roid=0',
                    cache: true,
                    success: function () {
                        webQQ.getContact(false);
                        webQQ.readData[HqmServiceObj.Data.ServiceID] = [];
                        webQQ.unreadData[HqmServiceObj.Data.ServiceID] = [];
                        webQQ.openChatDialog(HqmServiceObj.Data.ServiceID, euid, HqmServiceObj.Data.CompanyName, HqmServiceObj.Data.ServiceNickName, status, 1);
                    }
                });
            }
        }
    },

//洽洽名片
    webqqCard = {
        init: function () {
            webqqCard.div = Q('#webqq_card');
            webqqCard.div.on('mouseover', function () {
                webqqCard.div.show();
            }).on('mouseout', function (e) {
                if (Q.contains(this, e.relatedTarget, true)) {
                    return;
                }
                webqqCard.div.hide();
            });
        },
        getLevel: function (level) {
            var arr = [],
                i,
                j = 0,
                ico5 = parseInt(level / 256),
                ico4 = parseInt(level % 256 / 64),
                ico3 = parseInt(level % 256 % 64 / 16),
                ico2 = parseInt(level % 256 % 64 % 16 / 4),
                ico1 = parseInt(level % 256 % 64 % 16 % 4);
            for (i = 0; i < ico5; i++) {
                arr[j++] = "5";
            }
            for (i = 0; i < ico4; i++) {
                arr[j++] = "4";
            }
            for (i = 0; i < ico3; i++) {
                arr[j++] = "3";
            }
            for (i = 0; i < ico2; i++) {
                arr[j++] = "2";
            }
            for (i = 0; i < ico1; i++) {
                arr[j++] = "1";
            }
            return arr;
        },
        show: function (result) {
            if (result.CustomHead != undefined && result.CustomHead != '') {
                result.ImgUrl = 'http://hqmimg.hqew.com/customhead/' + result.CustomHead;
            } else {
                if (result.PersonHeadImg != undefined && result.PersonHeadImg != '') {
                    result.ImgUrl = '/searchImages/hqm/' + result.PersonHeadImg.substr(result.PersonHeadImg.lastIndexOf('/'));
                } else {
                    if (result.Gender = '男') {
                        result.ImgUrl = '/searchImages/hqm/f_01.gif';
                    }
                    if (result.Gender = '女') {
                        result.ImgUrl = '/searchImages/hqm/f_05.gif';
                    }
                }
            }
            Q('#webqq_card_img').attr({
                'src': result.ImgUrl
            });
            Q('#webqq_card_username').text(result.NickName == undefined ? '' : result.NickName.cut(14));
            if (result.AuditStatus == 0) {
                Q('#webqq_card_auth').style({
                    'display': 'none'
                });
                Q('#webqq_card_box').css('auth', '');
            } else {
                Q('#webqq_card_auth').style({
                    'display': 'none'
                });
                Q('#webqq_card_box').css('auth', '');
            }
            Q('#webqq_card_qq').css('g-ico-qq-off', '').css('g-ico-qq', '').css(result.HqmIsOnline == 0 ? 'g-ico-qq-off' : 'g-ico-qq').on('click', function () {
                HqmChat('result.UserID', 'result.UserGUID');
            });
            Q('#webqq_card_sign').text(result.PersonalSign == undefined ? '' : result.PersonalSign.cut(40)).attr({
                'title': result.PersonalSign
            }).style({
                'display': result.PersonalSign == undefined || result.PersonalSign == '' ? 'none' : ''
            });
            var qqLevel = '';
            Q.each(webqqCard.getLevel(result.HqmLevel), function () {
                qqLevel += '<i class=\"g-ico-qq-level' + this + '\"></i>';
            });
            Q('#webqq_card_level').html(qqLevel).attr({
                'title': '等级 ' + result.HqmLevel + ' 级'
            });
            Q('#webqq_card_phone').text(result.Phone == undefined ? '' : result.Phone.split(',')[0].cut(21));
            Q('#webqq_card_mobile').text(result.Mobile == undefined ? '' : result.Mobile.cut(11));
            Q('#webqq_card_email').text(result.Email == undefined ? '' : result.Email.cut(20));
            Q('#webqq_card_corpname').text(result.CompanyName == undefined ? '' : result.CompanyName.cut(40)).attr({
                'href': result.ShopUrl == 'freeshop' ? 'http://www.hqew.com/freeshop_' + result.UserID + '.html' : result.ShopUrl
            });
            Q('#webqq_card_cx').style({
                'display': result.IsHonest == 0 ? 'none' : ''
            });
            Q('#webqq_card_iscp').style({
                'display': result.IsISCP == 0 ? 'none' : ''
            });
            Q('#webqq_card_mic').style({
                'display': 1 ? 'none' : ''
            });
            Q('#webqq_card_led').style({
                'display': 1 ? 'none' : ''
            });
            Q('#webqq_card_bcp').style({
                'display': result.IsBCP == 0 ? 'none' : ''
            });
            Q('#webqq_card_600').style({
                'display': 1 ? 'none' : ''
            });
            Q('#webqq_card_wp').style({
                'display': result.IsVIPShop == 0 ? 'none' : ''
            });
            Q('#webqq_card_kgj').style({
                'display': 1 ? 'none' : ''
            });
            Q('#webqq_card_buy').style({
                'display': 1 ? 'none' : ''
            });
            Q('#webqq_card_coms').style({
                'display': result.CompanyIntegralCountOfTotal == undefined ? 'none' : ''
            }).attr({
                'title': '公司总成长值：' + result.CompanyIntegralCountOfTotal + '分'
            }).text(result.CompanyIntegralCountOfTotal);
        }
    },

//登录
    login = {
        Info: {},
        State: function () {
            login.Info.F !== false && Q.js({
                url: '/ajax/WebUserState.aspx',
                cache: false,
                success: function () {
                    Q('#login').html(login.Info.F ? '<a class=\"g-c-b g-ico-user\" href=\"http://ibsv2.hqew.com\">' + login.Info.N + '</a><a class=\"g-c-66 g-ff-s g-ml-10\" title=\"点击退出登录\" href=\"/member/ilogout.aspx\">[退出]</a>' : '请<a class=\"g-c-r\" href=\"/member/ilogin.aspx\">登录</a>，<a class=\"g-c-66 g-ml-5\" href=\"/member/ireg.aspx\">免费注册</a>');
                }
            });
        },
        Total: function () {
            var timer,
                check = function () {
                    if (login.Info.O !== undefined) {
                        Q('#onlineNum').text(login.Info.O ? '[有' + login.Info.O + '位会员在线]' : '');
                        Q('#inquiryNum').text(login.Info.I ? '[有' + login.Info.I + '次询价]' : '');
                        clearTimeout(timer);
                    } else {
                        timer = setTimeout(check, 1);
                    }
                };
            login.Info.F !== false ? check() : Q.js({
                url: '/ajax/WebUserState.htm',
                cache: true,
                success: check
            });
        },
        init: function () {
            login.type = '';
            login.qiaqia = false;
            login.login_tab = Q('#login_tab h2');
            login.login_switch = Q('#login_switch');
            login.login_user_change = Q('#login_user_change');
            login.login_bind_ignore = Q('#login_bind_ignore');
            login.login_submit = Q('#login_submit');
            login.login_verify_img = Q('#login_verify_img');
            login.login_keep_input = Q('#login_keep_input');
            login.login_msg = Q('#login_msg');
            login.login_verify = Q('#login_verify');
            login.login_mobile_link = Q('#login_mobile_link');
            login.login_cellnum = Q('#CellNum');
            login.login_cellpass = Q('#CellPass');
            login.login_username = Q('#UserName');
            login.login_userpass = Q('#UserPass');
            login.login_forget = Q('#forget');
            login.authTimer = null;
            //获取动态密码
            login.login_mobile_link.on('click', login.getAuth);
            //记住用户名密码
            login.login_username.val(Q.cookie('CooikeUserName'));
            login.login_userpass.val(Q.cookie('CooikePassword'));
            login.login_keep_input.attr({
                'checked': (Q.cookie('CooikeUserName') == '' ? false : true)
            });
            //找回密码
            login.login_forget.click(function () {
                login.login_msg.css('g-c-r g-ico-wrong', 'g-c-b g-ico-notice').show().text(login.login_forget.attr('title'));
            });
            //登录方式切换            
            login.login_tab.click(function () {
                login.setType(login.type != 'mobilelogin' ? 'mobilelogin' : login.qiaqia ? 'quick' : '');
                login.clearAuthTimer();
            });
            login.login_switch.click(function () {
                login.setType(login.type != 'mobilelogin' ? 'mobilelogin' : login.qiaqia ? 'quick' : '');
                login.clearAuthTimer();
            });
            //使用其它帐号登录
            login.login_user_change.click(function () {
                login.setType('');
            });
            //文本框鼠标滑过及获取焦点
            Q('#login_form .text').on('mouseover', function () {
                Q(this).style({
                    'borderColor': '#1057A7'
                });
            }).on('mouseout', function () {
                Q(this).style({
                    'borderColor': '#ccc'
                });
            });
            //关闭登录窗
            Q('#login_close, #login_bind_ignore').bind('click', function () {
                Q('#webqq_chat').hide();
                webQQ.close();
                login.clearAuthTimer();
            });
            //登录按钮背景切换
            login.login_submit.on('mouseover', function () {
                login.login_submit.css('over');
            }).on('mouseout', function () {
                login.login_submit.css('over', '');
            });
            //刷新验证码
            var src = login.login_verify_img.attr('url');
            login.login_verify_img.click(function () {
                login.login_verify_img.attr({
                    'src': src + '&' + Math.random()
                });
            });
        },
        getAuth: function () {
            login.type = login.type == 'mobilelogin' ? 'getmobileauthcode' : 'getbindingmobileauthcode';
            login.post(function () {
                login.type = login.type == 'getmobileauthcode' ? 'mobilelogin' : 'accountbindingmobile';
                login.login_cellpass.e[0].focus();
                Q.cookie('CooikeCellNum', login.login_cellnum.val(), 14);
                login.login_cellnum.attr({
                    'readOnly': true
                }).style({
                    'backgroundColor': '#f0f0f0'
                }).on('mouseover', function () { });
                login.login_mobile_link.on('click', function () { });
                var sec = 60;
                login.authTimer = setInterval(function () {
                    login.login_mobile_link.text((sec--) + 's倒计时');
                    sec < 0 && login.clearAuthTimer('重新获取动态密码');
                }, 1000);
            });
        },
        clearAuthTimer: function (s) {
            login.login_cellnum.attr({
                'readOnly': false
            }).style({
                'backgroundColor': ''
            }).on('mouseover', function () {
                login.login_cellnum.style({
                    'borderColor': '#1057A7'
                });
            });
            login.login_mobile_link.on('click', login.getAuth).text(s || '点击获取动态密码');
            clearInterval(login.authTimer);
        },
        setType: function (s) {
            login.type = s;
            var loginUser = Q('#login_user'),
                loginQiaqia = Q('#login_qiaqia'),
                loginMobile = Q('#login_mobile'),
                switchText,
                keepDisplay,
                changeDisplay,
                ignoreDisplay,
                submitText;
            switch (s) {
                case '':
                    switchText = '使用手机号直接登录';
                    keepDisplay = 'block';
                    changeDisplay = 'none';
                    ignoreDisplay = 'none';
                    submitText = '登 录';
                    loginUser.show();
                    loginQiaqia.hide();
                    loginMobile.hide();
                    Q(login.login_tab.e).eq(0).css('cur').siblings().css('cur', '');
                    login.login_msg.hide();
                    break;
                case 'quick':
                    switchText = '使用手机号直接登录';
                    keepDisplay = 'none';
                    changeDisplay = 'inline';
                    ignoreDisplay = 'none';
                    submitText = '快速登录';
                    loginUser.hide();
                    loginQiaqia.show();
                    loginMobile.hide();
                    Q(login.login_tab.e).eq(0).css('cur').siblings().css('cur', '');
                    login.login_msg.hide();
                    break;
                case 'mobilelogin':
                    switchText = '使用普通帐号登录';
                    keepDisplay = 'none';
                    changeDisplay = 'none';
                    ignoreDisplay = 'none';
                    submitText = '登 录';
                    loginUser.hide();
                    loginQiaqia.hide();
                    loginMobile.show();
                    Q(login.login_tab.e).eq(1).css('cur').siblings().css('cur', '');
                    login.login_msg.hide();
                    break;
                case 'mobilebinding':
                    switchText = '使用普通帐号登录';
                    keepDisplay = 'none';
                    changeDisplay = 'none';
                    ignoreDisplay = 'none';
                    submitText = '绑定帐号';
                    loginUser.show();
                    loginQiaqia.hide();
                    loginMobile.hide();
                    break;
                case 'accountbindingmobile':
                    switchText = '使用普通帐号登录';
                    keepDisplay = 'none';
                    changeDisplay = 'none';
                    ignoreDisplay = 'inline';
                    submitText = '绑定手机';
                    loginUser.hide();
                    loginQiaqia.hide();
                    loginMobile.show();
                    break;
            }
            switchText && login.login_switch.text(switchText);
            submitText && login.login_submit.val(submitText);
            changeDisplay && login.login_user_change.style({
                'display': changeDisplay
            });
            ignoreDisplay && login.login_bind_ignore.style({
                'display': ignoreDisplay
            });
            keepDisplay && Q('#login_keep').style({
                'display': keepDisplay
            });
            login.login_verify.hide();
        },
        post: function (callback) {
            var loginVerifyInput = Q('#login_verify_input'),
                loginTime,
                uparam,
                sparam;
            switch (login.type) {
                case '':
                    loginTime = parseInt(Q.cookie('loginTime1', parseInt(Q.cookie('loginTime1') == '' ? 0 : Q.cookie('loginTime1')) + 1));
                    uparam = '?act=&UserName=' + login.login_username.val() + '&Password=' + login.login_userpass.val() + '&IsRemember=' + (login.login_keep_input.attr('checked') ? 1 : 0) + '&ValidateCode=' + loginVerifyInput.val() + '&LoginTime=' + loginTime;
                    break;
                case 'getmobileauthcode':
                    loginTime = parseInt(Q.cookie('loginTime2', parseInt(Q.cookie('loginTime2') == '' ? 0 : Q.cookie('loginTime2')) + 1));
                    uparam = '?act=getmobileauthcode&MobilePhone=' + login.login_cellnum.val() + '&ValidateCode=' + loginVerifyInput.val() + '&LoginTime=' + loginTime;
                    break;
                case 'getbindingmobileauthcode':
                    loginTime = parseInt(Q.cookie('loginTime6', parseInt(Q.cookie('loginTime6') == '' ? 0 : Q.cookie('loginTime6')) + 1));
                    uparam = '?act=getbindingmobileauthcode&MobilePhone=' + login.login_cellnum.val() + '&ValidateCode=' + loginVerifyInput.val() + '&LoginTime=' + loginTime;
                    break;
                case 'mobilelogin':
                    loginTime = parseInt(Q.cookie('loginTime3', parseInt(Q.cookie('loginTime3') == '' ? 0 : Q.cookie('loginTime3')) + 1));
                    uparam = '?act=mobilelogin&MobilePhone=' + login.login_cellnum.val() + '&CheckAuthCode=' + login.login_cellpass.val() + '&ValidateCode=' + loginVerifyInput.val();
                    break;
                case 'mobilebinding':
                    loginTime = parseInt(Q.cookie('loginTime4', parseInt(Q.cookie('loginTime4') == '' ? 0 : Q.cookie('loginTime4')) + 1));
                    uparam = '?act=mobilebinding&UserName=' + login.login_username.val() + '&Password=' + login.login_userpass.val() + '&MobilePhone=' + login.login_cellnum.val() + '&CheckAuthCode=' + login.login_cellpass.val() + '&ValidateCode=' + loginVerifyInput.val() + '&LoginTime=' + loginTime;
                    break;
                case 'accountbindingmobile':
                    loginTime = parseInt(Q.cookie('loginTime5', parseInt(Q.cookie('loginTime5') == '' ? 0 : Q.cookie('loginTime5')) + 1));
                    uparam = '?act=accountbindingmobile&MobilePhone=' + login.login_cellnum.val() + '&CheckAuthCode=' + login.login_cellpass.val() + '&ValidateCode=' + loginVerifyInput.val() + '&LoginTime=' + loginTime;
                    break;
                case 'quick':
                    uparam = '?act=quick';
                    Q('#login_qiaqia_user input').each(function () {
                        this.checked == true && (sparam = this.value);
                    });
                    break;
            }
            Q.ajax({
                'url': '/member/iAjaxLogon.aspx' + uparam,
                'type': 'json',
                'param': sparam,
                'start': function () { },
                'stop': function () { },
                'success': function (result) {
                    if (result.ResultCode == 0) {
                        if (login.type == '' && result.IsBindingMobile == 0) {
                            login.setType('accountbindingmobile');
                            login.login_cellnum.val(result.MobilePhone);
                            login.login_msg.css('g-c-r g-ico-wrong', 'g-c-b g-ico-notice').show().text('免费绑定手机，享受免费手机登录等丰富服务！');
                            Q('#login_close, #login_bind_ignore').bind('click', function () {
                                callback();
                            });
                        } else {
                            callback();
                        }
                    } else {
                        result.Message != '' && login.login_msg.css('g-c-b g-ico-notice', 'g-c-r g-ico-wrong').show().text(result.Message);
                        if (result.LoginCount > 2) {
                            login.login_verify.show();
                            login.login_verify_img.e[0].click && login.login_verify_img.e[0].click();
                        }
                        if (result.ResultCode == 100) { //获取短信异常
                            login.type = login.type == 'getmobileauthcode' ? 'mobilelogin' : 'accountbindingmobile';
                        } else if (result.ResultCode == 110) { //手机已注册
                            login.setType('mobilebinding');
                            login.login_username.val(result.UserName);
                            login.login_msg.css('g-c-r g-ico-wrong', 'g-c-b g-ico-notice').show().text('继续使用手机登录需要绑定您已有帐号！');
                        } else if (result.ResultCode == 120) { //手机登录异常
                        } else if (result.ResultCode == 130) { //手机绑定异常
                        }
                    }
                }
            });
        },
        getUsers: function () {
            try {
                var users = new ActiveXObject("HqmQL.QuickLogin").GetClientUsers(),
                    i = users.lastIndexOf('{END}'),
                    tmp = '';
                users = Q.eval(i > 0 ? users.substring(0, i) : '[]');
                if (users.length > 0) {
                    login.qiaqia = true;
                    Q.each(users, function () {
                        tmp += '<input name=\"login_qiaqia_name\" type=\"radio\" id=\"login_qiaqia' + this.s1 + '\" value=\"&uid=' + this.s1 + '&key=' + this.s3 + '&ug=' + this.s5 + '&rnd=' + this.s6 + '&rtime=' + this.s7 + '\" /><label for=\"login_qiaqia' + this.s1 + '\" class=\"g-ml-5 g-c-66\">' + this.s4.cut(10) + '[' + this.s2.cut(10) + ']</label><br />';
                    });
                    Q('#login_qiaqia_user').html(tmp).find('input').eq(0).attr({
                        'checked': true
                    });
                } else {
                }
            } catch (e) {
            }
            login.setType(login.qiaqia ? 'quick' : '');
            if (login.qiaqia == false && Q.cookie('CooikeCellNum') != '') {
                login.login_cellnum.val(Q.cookie('CooikeCellNum'));
                login.setType('mobilelogin');
            }
        },
        show: function (callback) {
            login.Info.F ? callback() : popShow({
                elt: '#login_popup',
                hide: '#login_close',
                callback: function () {
                    var cellTip = Q('<div class=\"g-notice\" style=\"bottom:30px;left:40px;font-size:12px;font-weight:normal;\">采购商快速通道<u></u></div>').appendTo(Q(login.login_tab.e).eq(1).style({
                        'position': 'relative'
                    }));
                    setTimeout(function () {
                        cellTip.remove();
                    }, 8000);
                    login.getUsers();
                    Q('#login_form').e[0].onsubmit = function () {
                        login.post(function () {
                            webQQ.getContact(false);
                            login.Info.F = true;
                            login.State();
                            callback();
                            popHide();
                        });
                        return false;
                    };
                }
            });
        }
    },

    signOut = function () {
        window.location = 'http://www.hqew.com/member/ilogout.aspx';
    };

//洽洽控件检测
var uid, type, autoID, Guid, callType;

function HQMCheck() {
    try {
        return null != new ActiveXObject("HqmTalk.HqmPlugin");
    } catch (err) {
        return false;
    }
}

function HqmChat(userid, uguid, pguid, inquire) {
    if (HQMCheck()) {
        window.location.href = "hqew://?uid=" + userid + "&uname=" + uguid + (inquire ? '&rfq=' + inquire.ic + '&rfq1=' + inquire.PModel.encodeUrl(0) + '&rfq2=' + inquire.PQuantity.encodeUrl(0) + '&rfq3=' + inquire.S1.encodeUrl(0) + '&rfq4=' + inquire.S2.encodeUrl(0) + '&rfq5=' + inquire.S3.encodeUrl(0) + '&star=' + inquire.star : '');
    } else {
        window.open("/Web/Hqen/Imrfq/Imrfqidic.aspx?uguid=" + uguid + "&pguid=" + pguid, '_blank');
    }
}

function HqmChatIBS(userid, uguid) {
    if (HQMCheck()) {
        window.location.href = "hqew://?uid=" + userid + "&uname=" + uguid;
        return true;
    } else {
        return false;
    }
}

//参数UserID:对方ID,type:产品类型，autoID：产品标识，Guid:产品GUID 询报价
function HqmChatRFQ(userid, uguid, type, autoId, guid) {
    if (HQMCheck()) {
        window.location.href = "hqew://?uid=" + userid + "&uname=" + uguid + "&RFQType=1&PType=" + type + "&PID=" + autoId + "&PGuid=" + guid;
    } else {
        window.open("/Web/Hqen/Imrfq/Imrfqidic.aspx?uguid=" + uguid + "&imrfqtype=" + type + "&autoid=" + autoId + "&guid=" + guid, '_blank');
    }
}

var HqmServiceObj = null;

function HqmService(userid, uguid, stype, entuid, roid, inquire) {
    var defaultClientUrl = "hqew://?uid=" + userid + "&uname=" + uguid,
        entClientUrl = "hqew://?uid=" + userid + "&uname=" + uguid +
             "&entuid=" + entuid + "&roid=" + roid;

    try {
        Q.js({
            url: 'http://hqmim.hqew.com/ajax/services.aspx?uid=' + userid + '&ug=' + uguid + '&type=' + stype + '&entuid=' + entuid + '&roid=' + roid,
            cache: true,
            success: function () {
                if (HqmServiceObj != undefined) {
                    var resultCode = 9;
                    if (HqmServiceObj['ResultCode'] != undefined) {
                        resultCode = HqmServiceObj['ResultCode'].toString();
                    }
                    if (resultCode == "0") {
                        if (HqmServiceObj['Data']['EntID'] == "0") {
                            window.location.href = defaultClientUrl;
                        } else if (HqmServiceObj['Data']['ServiceID'] != undefined) {
                            window.location.href = "hqew://?uid=" + HqmServiceObj['Data']['ServiceID'] + "&uname=" + HqmServiceObj['Data']['Guid'] + "&entuid=" + HqmServiceObj['Data']['EntID'] + "&roid=" + HqmServiceObj['Data']['RoID'] +
                                     (inquire ? '&rfq=' + inquire.ic +
                                     '&rfq1=' + inquire.PModel.encodeUrl(0) +
                                     '&rfq2=' + inquire.PQuantity.encodeUrl(0) +
                                     '&rfq3=' + inquire.S1.encodeUrl(0) +
                                     '&rfq4=' + inquire.S2.encodeUrl(0) +
                                     '&rfq5=' + inquire.S3.encodeUrl(0) +
                                     '&star=' + inquire.star : '');
                        }
                    }
                } else {
                    window.location.href = defaultClientUrl;
                    //"hqew://?uid=" + userid + "&uname=" + uguid+'&entuid='+entuid+'&roid='+roid;
                }
                HqmServiceObj = null;
            }
        });
    } catch (err) {
        //window.open("/Web/Hqen/Imrfq/Imrfqidic.aspx?uguid=" + uguid+"&pguid=",target='_blank');
    }
}

Q(function () {
    login.init();
    webQQ.init();
});