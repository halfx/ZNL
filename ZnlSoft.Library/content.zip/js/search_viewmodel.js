function QuoteViewModelBase(model) {
    var self = this;

    self.rawQuery = model.query;
    self.query = ko.observable($.extend({}, model.query));

    self.quotes = model.quotes;
    self.total = model.total;
    self.quoteStocks = model.stocks;

    self.displayedPages = model.displayedPages;
    self.currentPage = model.currentPage;
    self.enablePagePrev = ko.observable(model.currentPage > 1);
    self.enablePageNext = ko.observable(model.enablePageNext);
    self.hasPageNext = model.currentPage > 1 || model.total > model.quotes.length;

    self.supplierCardVisible = ko.observable(false);
    self.supplierTemplateName = ko.observable('emptyTemplate');
    self.last = ko.observable({});
    self._companyCard = null;

    self.isCurrentPage = function (pageIndex) {
        return pageIndex == self.currentPage;
    };

    self.jumpToPrevPage = function () {
        self.enablePagePrev()
          && self.jumpTo({ page: (self.currentPage - 1) });
    };

    self.jumpToNextPage = function () {
        self.enablePageNext()
          && self.jumpTo({ page: (self.currentPage + 1) });
    };

    self.jumpToPage = function (page) {
        self.currentPage != page
          && self.jumpTo({ page: (page) });
    };

    self.openUrl = function (item) {
        util.openUrl(item.supplierUrl);
    };

    self.getQuoteById = function(id) {
        return self.quotes[id - 1];
    };

    self.chooseItem = function (quote, e) {
        quote.clicked = true;

        $(e.target).closest('.quote-btn').addClass('clicked');
        $('#quote' + quote.id + ' .quote-btn').addClass('clicked');
        util.openQuote(quote);
    };

    self.openQuoteStock = function (quote) {
        quote.clicked = true;
        util.openQuote(quote)
    };

    self._processContacts = function (quote) {
        var lines, line, contacts, contact, frags, i;

        contacts = [];
        if (!quote.contact) return contacts;

        lines = quote.contact.split(',');
        if (!lines.length) return contacts;

        for (i = 0; i < lines.length; i++) {
            line = lines[i];
            frags = line.split(' ');
            contact = { name: frags[1] || '' };
            frags = frags[0].split('-');

            if (frags.length >= 3) {
                contact.intl = frags[0];
                contact.areaCode = frags[1];
                contact.telephone = frags[2];
            } else if (frags.length == 2) {
                contact.intl = '';
                contact.areaCode = frags[0];
                contact.telephone = frags[1];
            } else {
                contact.intl = '';
                contact.areaCode = '';
                contact.telephone = frags[0];
            }
            contacts.push(contact);
        }
        return contacts;
    };

    self._processQQ = function (quote) { };

    self._processQuote = function (quote) { };

    self._init = function (model) {
        var quote, i,
            supplierNames;

        //supplierNames = [];
        self._companyCard = $('#companyCard');
        if (model.quotes && model.quotes.length) {
            for (i = 0; i < model.quotes.length; i++) {
                quote = model.quotes[i];
                quote.index = i + 1;
                quote.supplierTag = { state: 0 };
                quote.clicked = false;

                self._processQuote && self._processQuote(quote);
                self._processQQ && (quote.qqs = self._processQQ(quote));
                self._processContacts && (quote.contacts = self._processContacts(quote));

                //supplierNames.push(quote.supplierName);
            }
        }

        if (model.stocks && model.stocks.length) {
            for (i = 0; i < model.stocks.length; i++) {
                quote = model.stocks[i];
                quote.index = i + 1;
                quote.supplierTag = { state: 0 };
                quote.clicked = false;

                supplierNames.push(quote.supplierName);
            }
        }

        //util.loadTags(supplierNames);
    };

    self._init.call(self, model);

    self.jumpTo = function (opt) {
        var query = $.extend({}, self.rawQuery)

        opt && (query = $.extend(query, opt));
        util.changeQuoteQuery(
            self._buildUrl(query),
            query
        );
    };

    self.search = function () {
        var q = self.query(),
            query = self._getSearchQuery({
                partNo: q.partNo.trim().toUpperCase(),
                brand: '',
                pack: '',
                batch: '',
                qty: 0,
                exact: q.exact,
                page: 1
            });
        self._processSearchQuery(query);
        self.jumpTo(query);
    };

    self._processSearchQuery = function(q) {};

    self.filterSearch = function () {
        throw 'NotImplement';
    };

    self._buildUrl = function (q) {
        var frags = [];
        frags.push('p=' + encodeURIComponent(q.partNo));
        frags.push('brand=' + encodeURIComponent(q.brand || ''));
        frags.push('pack=' + encodeURIComponent(q.pack || ''));
        frags.push('batch=' + encodeURIComponent(q.batch || ''));
        frags.push('qty=' + q.qty);
        frags.push('exact=' + (q.exact ? 1 : 0));
        frags.push('area=' + q.area);
        frags.push('order=' + q.order);
        frags.push('page=' + q.page);
        self._mapQueryFrags(frags, q);
        return self._getBaseUrl() + '?' + frags.join('&');
    };

    self._getSearchQuery = function (q) {
        return q;
    }

    self._getBaseUrl = function () {
        throw 'NotImplement';
    };

    self._mapQueryFrags = function (frags, q) {};

    self.assignTag = function () {
        util.assignTag(self.last().supplierName);
    };

    self.showSupplierCard = function(q, e) {
        var $self = $(e.target),
            $card = self._companyCard,
            pos = $self.position();

        self.last(q);
        self.supplierTemplateName('supplierTemplate');
        self._processSupplierCard($self, $card, m);

        $card.css({
                top: pos.top + $self.height() + 'px',
                left: pos.left + 50 + 'px'
            })
            .show();
    };

    self.hideSupplierCard = function(q, e) {
        var $self = e.relatedTarget && $(e.relatedTarget);

        if(!($self && $self.hasClass('supplier-name')))
            self._companyCard.hide();
    };

    self.holdSupplierCard = function() {
        self._companyCard.show();
    };

    self._processSupplierCard = function($node) {};

    self.toggleMoreQuotes = function(q, e) {
        var $self = $(e.target),
            $main = $self.closest('.main'),
            $container = $('#sibling' + q.id),
            active = $main.hasClass('active');

        if (active) {
            $main.removeClass('active');
            $container.slideUp('fast');
        } else {
            $main.addClass('active');
            $container.slideDown('fast');
        }
    };

    self.openQuote = function() {
        var q = arguments[0],
            e = arguments[1],
            $btn = $(e.target);

        $btn.addClass('clicked');
        self._processQuote(q);
    };

    self.openSiblingQuote = function(m, e) {
        var $btn = $(e.target),
            $row = $btn.closest('.quote-row'),
            mainId = $row.parent().attr('id').substr(7),
            q = self._getSiblingQuote($row, mainId, m);

        $btn.addClass('clicked');
        self._processQuote(q)
    };

    self._processQuote = function(q) {
        q.site = self.rawQuery.site;
        q.clicked = true;
        util.openQuote(q);
    };

    self._getSiblingQuote = function($row, mainId) {
        var mainQuote = self.quotes[mainId - 1],
            quote = $.extend({}, mainQuote),
            text;

        quote.partNo = $row.find('.col3 .model').attr('title');
        quote.brand = $row.find('.col5').text();
        quote.batch = $row.find('.col6').text();
        quote.pack = $row.find('.col7').text();
        quote.remark = $row.find('.col8 .remark').attr('title');
        quote.area = $row.find('.col9').attr('title');
        text = $row.find('.col4').text();
        quote.qty = text ? parseInt(text) : 0;
        return quote;
    };

    self.openSupplierUrl = function() {
        util.openUrl(findQuote($(this)).supplierUrl);
    }

    self.queryQty = ko.computed({
        read: function() {
            var q = self.query();
            return q.qty == 0 ? '' : q.qty;
        },
        write: function(value) {
            var q = self.query(),
                qty = parseInt(value);
            q.qty = isNaN(qty) ? 0 : qty;
        },
        owner: this
    });

    self.lastLoadingTag = ko.computed(function () {
        var quote = self.last();
        return quote.supplierTag && quote.supplierTag.state == 0;
    });

    self.lastHasTag = ko.computed(function () {
        var quote = self.last();
        return quote.supplierTag && quote.supplierTag.state == 1;
    });

    self.lastNoTag = ko.computed(function () {
        var quote = self.last();
        return quote.supplierTag && quote.supplierTag.state == 2;
    });

    self.lastTagError = ko.computed(function () {
        var quote = self.last();
        return quote.supplierTag && quote.supplierTag.state == 3;
    });

    self.lastHasCellphone = ko.computed(function () {
        var quote = self.last();
        return quote.cellphone != null && quote.cellphone.length > 0;
    });

    self.lastHasContact = ko.computed(function () {
        var quote = self.last();
        if (quote && quote.contacts == undefined)
            quote.contacts = self._processContacts(quote);
        return quote.contact != null && quote.contacts.length > 0;
    });

    self.lastHadAddress = ko.computed(function () {
        var quote = self.last();
        return quote.address != null && quote.address.length > 0;
    });

    self.lastHasFax = ko.computed(function () {
        var quote = self.last();
        return quote.fax != null && quote.fax && quote.fax.length > 0;
    });

    self.lastHasQQ = ko.computed(function () {
        var quote = self.last();
        return quote.qq != null && quote.qq && quote.qq.length > 0;
    });
}

function HqewQuoteViewModel(model) {
    var self = this;

    self.deliveryCardVisible = ko.observable(false);
    self.honestyCardVisible = ko.observable(false);
    self._honestyCard = self.deliveryCard = null;

    function init(model) {
        // todo: set area value ugly, think binding
        $('#area').val(model.query.area);
        self._readPageSizeCookie(model.query);
        self._readSortCookie(model.query);
        self._honestyCard = $('#honestyCard');
        self._deliveryCard = $('#deliveryCard');
    }

    self._readPageSizeCookie = function(query) {
        var pageSize = $.cookie('ICSearchPageSize');
        query.pageSize = pageSize || 50;
    };

    self._readSortCookie = function(query) {
        var order = $.cookie('IsHonest');
        if(order == '1') {
            query.order = 'honesty';
            return;
        }

        order = $.cookie('IsAPayNum');
        if(order == '1')
        {
            query.order = 'delivery';
            return;
        }

        query.order = '';
    }

    init(model);
    QuoteViewModelBase.call(self, model);

    self._processSupplierCard = function($self, $card) {
        var data = Q.eval($self.attr('data')),
            $cytTag = $self.closest('li').siblings('.col11').find('.cyt-tag'),
            $csi = $card.find('.csi'),
            $bcp = $card.find('.bcp'),
            $iscp = $card.find('.iscp'),
            $report = $card.find('.report'),
            $cytCopyTag = $card.find('.cyt'),
            $delivery = $card.find('.delivery'),
            deliveryUrl;

        data.ico.bcp === 1 ? $bcp.show() : $bcp.hide();
        if (data.ico.iscp[0] === 1) {
            $iscp.show();
            $report.show()
                .attr('href', '/iscp/SelectReportMode.aspx?userid=' + data.ico.iscp[1] + '&StockInfo=' + data.ico.iscp[2]);
        } else {
            $iscp.hide();
            $report.hide();
        };

        $csi.attr('href', $self.attr('href') + '/csi.html');

        if (data.APayNumBefore === '0') {
            $delivery.hide();
        } else {
            deliveryUrl = $self.attr('href') + '/hqepayTopic.html';
            $delivery.find('.month').text(data.APayNumBefore)
                    .attr('href', deliveryUrl).end()
                .find('.total').text(data.APayNum)
                    .attr('href', deliveryUrl).end()
                .find('.rank u').removeClass('level')
                    .addClass('level' + data.APayLevel).end()
                .show();
        }

        if ($cytTag.length) {
            $cytCopyTag.removeClass().addClass($cytTag.attr('class'))
                .attr('href', $cytTag.attr('href'))
                .show();
        } else {
            $cytCopyTag.hide();
        }
    };

    self.showDeliveryCard = function(q, e) {
        var $self = $(e.target),
            $card = self._deliveryCard,
            $supplier = $self.closest('.col2').find('.supplier-name'),
            $epay = $card.find('.epay'),
            data = Q.eval($supplier.attr('data')),
            deliveryUrl = $supplier.attr('href') + '/hqepayTopic.html',
            pos = $self.offset();

        if($self.hasClass('epay')) {
            $epay.hide();
        } else {
            $epay.show();
        }

        $card.find('.month').text(data.APayNumBefore)
                .attr('href', deliveryUrl).end()
            .find('.total').text(data.APayNum)
                .attr('href', deliveryUrl).end()
            .find('.top').text(data.APayRank).end()
            .find('.rank u')
                .removeClass()
                .addClass('level' + data.APayLevel).end()
            .css({
                top: (pos.top + $self.height()) + 'px',
                left: pos.left + 'px'
            })
            .show();
    };

    self.hideDeliveryCard = function() {
        self._deliveryCard.hide();
    };

    self.holdDeliveryCard = function() {
        self._deliveryCard.show();
    };

    self.showHonestyCard = function(q, e) {
        var $self = $(e.target),
            $card = self._honestyCard,
            $title = $card.find('.title'),
            $userType = $card.find('.type'),
            $auth = $card.find('.auth'),
            $shop = $card.find('.shop'),
            $amount = $card.find('.amount'),
            $score = $card.find('.score'),
            $age = $card.find('.age'),
            title = $self.closest('.col11').siblings('.col2').find('.supplier-name').text(),
            data = Q.eval($self.attr('data')),
            pos = $self.position(),
            hasGuarantee = false,
            $guarantee, url;

        url = '/bussiness/honesty_' + data.RndCode + '.html';
        $title.html(title);
        $score.text(data.HonestyNum + '分')
                .attr('href', url)
                .attr('target', '_blank');
        $age.text(data.memberage);

        if($self.attr('class').indexOf('eim') > -1)
        {
            $userType.attr('title', 'EIM会员');
        } else {
            $userType.attr('title', '诚易通会员');
        }

        if(data.AuthType == '1') {
            $auth.attr('href', url).addClass('ico').text('个体经营');
        }else if(data.AuthType == '2' || data.AuthType == '3') {
            $auth.attr('href', url).addClass('ico').text('已核实');
        }else {
            $auth.attr('href', url).removeClass('ico').text('暂未核实');
        }

        if(data.IsEntityAuthen == '1') {
            $shop.attr('href', url).addClass('ico').text('已认证');
        } else {
            $shop.attr('href', url).removeClass('ico').text('暂未认证');
        }

        if(data.IsGuarantee == 'true') {
            $guarantee = $self.siblings('.guaranty');
            $amount.html('&yen;' + data.AccountToal)
                .attr('href', $guarantee.attr('href'))
                .attr('target', '_blank')
            hasGuarantee = true;
        }

        if(!hasGuarantee) {
            $amount.html('&yen;0')
                .attr('href', 'javascript:;')
                .attr('target', '');
        }

        $card.css({
            top: (pos.top + $self.height() + 5) + 'px',
            left: (pos.left - 285) + 'px'
        })
            .show();
    };

    self.hideHonestyCard =function() {
        self._honestyCard.hide();
    };

    self.holdHonestyCard = function() {
        self._honestyCard.show();
    };

    self.openMallQuote = function(m, e) {
        var $btn = $(e.target),
            $row = $btn.closest('.quote-row')
            q = self._getOtherQuote($row);

        $btn.addClass('clicked');
        self._processQuote(q)
    };

    self.openMallOwnQuote = function(m, e) {
        var $btn = $(e.target),
            $row = $btn.closest('.quote-row')
            q = self._getOtherQuote($row);

        $btn.addClass('clicked');
        self._processQuote(q)
    };

    self._getOtherQuote = function($row) {
        var quote = {},
            text;
        quote.partNo = $row.find('.col3 .model').attr('title');
        quote.brand = $row.find('.col5').text();
        quote.batch = $row.find('.col6').text();
        quote.pack = $row.find('.col7').text();
        quote.remark = $row.find('.col8 .remark').attr('title');
        quote.area = $row.find('.col9').attr('title');
        quote.supplierName = $row.find('.col2 .supplier-name').text();
        text = $row.find('.col4').text();
        quote.qty = text ? parseInt(text) : 0;
        return quote;
    };

    self._getBaseUrl = function () {
        return '//www.hqew.com/local/ic/search';
    };

    self._mapQueryFrags = function (frags, q) {
        self._setSort(q);
        self._setPageSize(q);

        frags.push('c=' + (q.category || ''));
        frags.push('cod=' + (q.cod ? 1 : 0));
        frags.push('pageSize=' + q.pageSize);
    };

    self._setPageSize = function(q) {
        if(q.pageSize == 100) {
            $.cookie('ICSearchPageSize', 100)
        } else {
            $.removeCookie('ICSearchPageSize');
        }
    };

    self._setSort = function(q) {
        var opt;
        if(q.order == self.rawQuery.order)
            return;

        opt = {
            path: '/'
        };
        if(q.order == 'honesty') {
            $.cookie('IsHonest', 1, opt);
            $.cookie('IsAPayNum', 0, opt);
        } else if (q.order == 'delivery') {
            $.cookie('IsHonest', 0, opt);
            $.cookie('IsAPayNum', 1, opt);
        }else {
            $.cookie('IsHonest', 0, opt);
            $.cookie('IsAPayNum', 0, opt);
        }
    };

    self._getSearchQuery = function (q) {
        q.cod = 0;
        return q;
    }

    self._processSearchQuery = function(q) {
        q.category = ''
    };

    self.filterSearch = function () {
        var q = self.query();

        self.jumpTo({
            category: 1000,
            brand: q.brand || '',
            pack: q.pack || '',
            batch: q.batch || '',
            qty: q.qty,
            exact: false,
            cod: q.cod,
            page: 1
        });
    }

    self.matchArea = function (area) {
        return self.query().area == area;
    };

    self.matchPageSize = function (pageSize) {
        return self.query().pageSize == pageSize;
    }

    self.isHonestySort = ko.computed(function () {
        return self.query().order === 'honesty';
    });

    self.isDeliverySort = ko.computed(function () {
        return self.query().order === 'delivery';
    });

    self.changeArea = function (m, e) {
        var $self = $(e.target),
            area;

        if(e.target.nodeName === 'A') {
            (!$self.hasClass('active')) && (area = $self.attr('data'));
        }else {
            area = $self.val();
            (m.rawQuery.area == area) && (area = null);
        }

        area && self.jumpTo({ area: area, page: 1 });
    };

    self.changePageSize = function (m, e) {
        var $self = $(e.target);

        !($self.hasClass('active'))
            && self.jumpTo({ pageSize: $self.text(), page: 1 });
    };

    self.sortQuotes = function (m, e) {
        var $self = $(e.target),
            order = $self.attr('data');

        self.jumpTo({
            order: $self.hasClass('active') ? '' : order,
            page: 1
        });
    };

    self.jumpToMall = function() {
        window.open('//www.hqchip.com/search/' + encodeURI(self.rawQuery.partNo) + '.html');
    };

    self.openMallPage = function() {
        window.open('//www.partinchina.com/search_' + encodeURI(self.rawQuery.partNo) + '.html');
    };

    ($('#mallQuotes').length) && (new Marquee('mallQuotes', 0, 2, 988, 45, 20, 3000, 3000, 45));
}

function IcnetQuoteViewModel(model) {
    var self = this;

    self.qtySort = null;

    function init(m) {
        if(m.query.order == 'up') {
            self.qtySort = 1;
        }else if(m.query.order == 'down') {
            self.qtySort = 2;
        }
    }

    init(model);
    QuoteViewModelBase.call(self, model);

    self.filterSearch = function () {
        var q = self.query();

        self.jumpTo({
            brand: q.brand || '',
            pack: q.pack || '',
            batch: q.batch || '',
            qty: q.qty,
            page: 1,
            stock: q.stock || '',
            area: q.area || '',
            market: q.market || ''
        });
    }

    self._processSearchQuery = function(q) {
        q.order = '';
    };

    self._processSupplierCard = function($self, $card) {
        var $tags = $self.parents('.col2').find('.tags').eq(0),
            $cardTags = $card.find('.supplier .tags');

        if ($tags.children('a').length) {
            $cardTags.append($tags.html()).show();
        } else {
            $cardTags.empty().hide();
        }
    };

    self._getBaseUrl = function () {
        return '//www.ic.net.cn/local/ic/search';
    };

    self._mapQueryFrags = function(frags, q) {
        frags.push('stock=' + q.stock);
        frags.push('market=' + (q.market || ''));
    };

    self.sortQtyUp = function() {
        self.jumpTo({
            order: 'up'
        });
    };

    self.sortQtyDown = function() {
        self.jumpTo({
            order: 'down'
        });
    };
}

function DzscQuoteViewModel(model) {
    var self = this;

    function init(model) {
        var quotes = model.quotes,
            q, k;
        if(quotes && quotes.length) {
            for(k in quotes) {
                q = quotes[k];
                q.siblings = new DzscSiblingsController(q, model.query);
            }
        }
    }

    init(model);
    QuoteViewModelBase.call(self, model);

    self.filterSearch = function () {
        var q = self.query();

        self.jumpTo({
            brand: q.brand || '',
            pack: q.pack || '',
            batch: q.batch || '',
            qty: q.qty,
            area: q.area,
            order: q.order,
            page: 1
        });
    };

    self._getBaseUrl = function () {
        return '//www.dzsc.com/local/ic/search';
    };

    self._mapQueryFrags = function (frags, q) {
        frags.push('plselect=', (q.order || ''));
    };

    self.toggleMoreQuotes = function(q, e) {
        var $self = $(e.target),
            $main = $self.closest('.main'),
            active = $main.hasClass('active'),
            $container = $('#sibling' + q.id);

        if (active) {
            $main.removeClass('active');
            q.siblings.hide($container);
        } else {
            $main.addClass('active');
            q.siblings.show($container);
        }
    };

    self.getSiblings = function(mainId) {
        return self.getQuoteById(mainId).siblings;
    };
}

function Cecb2bQuoteViewModel(model) {
    var self = this;

    function init(model) {
        var quotes = model.quotes,
            $card = $('#companyCard'),
            q, k;
        if(quotes && quotes.length) {
            for(k in quotes) {
                q = quotes[k];
                q.siblings = new Cecb2bSiblingsController(q, model.query);
                q.supplierCard = new Cecb2bSuppplierCardController(q, $card);
            }
        }
    }

    init(model);
    QuoteViewModelBase.call(self, model);

    self._getBaseUrl = function () {
        return '//s.cecb2b.com/local/ic/search';
    };

    self.filterSearch = function () {
        var q = self.query();

        self.jumpTo({
            brand: q.brand || '',
            pack: q.pack || '',
            batch: q.batch || '',
            qty: q.qty,
            area: q.area,
            order: q.order,
            page: 1
        });
    };

    self._processQuote = function(q) {
        q.supplierCard.load(function() {
            q.site = self.rawQuery.site;
            q.clicked = true;
            if(q.qqArray && !q.qq)
                q.qq = q.qqArray.join('/');
            util.openQuote(q);
        });
    };

    self.openMallQuote = function(m, e) {
        var $btn = $(e.target),
            $row = $btn.closest('.quote-row')
            q = self._getOtherQuote($row);

        $btn.addClass('clicked');
        self._processQuote(q)
    };

    self._getOtherQuote = function($row) {
        var quote = {},
            text;
        quote.partNo = $row.find('.col3 .model').attr('title');
        quote.brand = $row.find('.col5').text();
        quote.batch = $row.find('.col6').text();
        quote.pack = $row.find('.col7').text();
        quote.remark = $row.find('.col8 .remark').attr('title');
        quote.area = $row.find('.col9').attr('title');
        quote.supplierName = $row.find('.col2 .supplier-name').text();
        text = $row.find('.col4').text();
        quote.qty = text ? parseInt(text) : 0;
        return quote;
    };

    self.showSupplierCard = function(q, e) {
        window.m.last(q);
        q.supplierCard.show(e);
    };

    self.toggleMoreQuotes = function(q, e) {
        var $self = $(e.target),
            $main = $self.closest('.main'),
            active = $main.hasClass('active'),
            $container = $('#sibling' + q.id);

        if (active) {
            $main.removeClass('active');
            q.siblings.hide($container);
        } else {
            $main.addClass('active');
            q.siblings.show($container);
        }
    };

    self.getSiblings = function(mainId) {
        return self.getQuoteById(mainId).siblings;
    };

    ($('#mallQuotes').length) && (new Marquee('mallQuotes', 0, 2, 988, 45, 20, 3000, 3000, 45));
}

function SiblingsControllerBase(mainQuote, query) {
    var self = this;

    self.state = ko.observable('init');
    self.active = false;

    self.mainQuote = mainQuote;
    self.query = query;
    self.items = ko.observableArray([]);
    self.templateName = ko.observable('emptyTemplate');

    function empty() { };

    self.show = function($container) {
        var state = self.state();
        if(state == 'init') {
            self._await($container);
            self._load($container);
        } else {
            self._innerShow(state, $container);
        }
    };

    self._load = function($container) {
        $.get(self._buildUrl(), function(response) {
                self._process(response, $container);
            })
            .error(function(response) {
                self.state('error');
                self._handleError(response, $container);
            });
    };

    self._await = function($container) {
        self.active = true;
        self.state('await');
        self.templateName('loadingSiblingQuoteTemplate');
        $container.fadeIn('fast');
    };

    self._innerShow = function(state, $container) {
        self.active = true;
        switch(state) {
            case 'error':
            case 'await':
                $container.fadeIn('fast');
                break;
            case 'done':
                $container.slideDown('fast');
                break;
            default:
                throw 'NotSupport';
        }
    };

    self.hide = function($container) {
        var state;

        self.active = false;
        state = self.state();
        if(state == 'await' || state == 'error') {
            $container.fadeOut('fast');
        } else {
            $container.slideUp('fast');
        }
    };

    self._process = function(response, $container) {
        self.state('done');
        self.items(self._parseSiblings(response));
        if(self.active) {
            $container.fadeOut('slow', function() {
                    self.templateName('siblingQuoteTemplate');
                    self.active && $container.slideDown('fast');
                });
        } else {
            self.templateName('siblingQuoteTemplate');
        }
    };

    self._handleError = function(response, $container) {
        if(self.active) {
            $container.fadeOut('slow', function() {
                    self.templateName('loadSiblingQuoteFaultedTemplate');
                    self.active && $container.fadeIn('fast');
                });
        } else {
            self.templateName('loadSiblingQuoteFaultedTemplate');
        }
    };

    self._buildUrl = undefined;
    self._parseSiblings = undefined;
}

function DzscSiblingsController(quote, query) {
    var self = this;

    SiblingsControllerBase.call(self, quote, query);

    self.siblingQuery = quote.siblingQuery;

    function parseQuote($q) {
        var q = {},
            text;

        q.partNo = $q.find('xinghao').text();
        q.brand = $q.find('changjia').text();
        q.batch = $q.find('pihao').text();
        q.pack = $q.find('fengzhuang').text();
        text = $q.find('shuliang').text();
        q.qty = text ? parseInt(text) : 0;
        q.remark = $q.find('note').text();
        return q;
    }

    self._parseSiblings = function(xml) {
        var $xml = $(xml),
            $quotes = $xml.find('info'),
            count = $quotes.length,
            quotes = [], i;

        for(i = 0; i < count; i++) {
            quotes.push(parseQuote($quotes.eq(i)));
        }
        return quotes;
    };

    self._buildUrl = function() {
        return '//www.dzsc.com/ic/sell_search_getother.asp?infoid=@mainId&stype=@stockType&partno=@partNo&searchtype=@type&_=@nonce'
            .fmt(function($1) {
                switch($1) {
                    case 'partNo':
                        return encodeURIComponent(self.siblingQuery[$1]);
                    case 'nonce':
                        return +(new Date());
                    default:
                        return self.siblingQuery[$1];
                }
            });
    };
}

function Cecb2bSiblingsController(quote, query) {
    var self = this;

    SiblingsControllerBase.call(self, quote, query);

    function parseQuote($q) {
        var q = {};

        q.partNo = $q.find('.c_xh h3 a').attr('title');
        q.brand = $q.find('.c_pp a').text();
        q.batch = $q.find('.c_ph').text();
        q.pack = $q.find('.c_fz').text();
        q.qty = parseInt($q.find('.c_sl').text());
        q.remark = $q.find('.xss').attr('title');
        return q;
    }

    self._parseSiblings = function(html) {
        var $html = $($.trim(html)),
            $quotes = $html.find('.searchList'),
            count = $quotes.length,
            quotes = [], i;

        for(i = 0; i < count; i++) {
            quotes.push(parseQuote($quotes.eq(i)));
        }
        return quotes;
    };

    self._buildUrl = function() {
        return '//s.cecb2b.com/vsearch/qiccorp.do?supplyId=@supplyId&corpid=@supplierId&q=@partNo'
            .fmt(function($1) {
                return $1 == 'partNo' ? encodeURIComponent(self.query[$1]) : self.mainQuote[$1];
            });
    };
}

function Cecb2bSuppplierCardController(quote, $card) {
    var self = this;

    self.active = false;
    self.state = ko.observable('init');

    self.quote = quote;
    self.$card = $card;
    self.templateName = ko.observable('emptyTemplate');

    self.show = function(e) {
        var state = self.state();
        self._setCardPosition(e)
        window.m.supplierTemplateName('supplierTemplate');
        if(state == 'init') {
            self._await();
            self._load();
        } else {
            self._innerShow(state);
        }
    };

    self._setCardPosition = function(e) {
        var $name = $(e.target),
            pos = $name.position();

        $card.css({
                top: pos.top + $name.height() + 'px',
                left: pos.left + 50 + 'px'
            });
    };

    self.load = function(cb) {
        var state = self.state();
        if(state == 'init') {
            $.get(self._buildUrl(), function(html) {
                    self._process(html);
                    cb && cb();
                })
                .error(function(err) {
                    cb && cb();
                });
        } else {
            cb && cb();
        }
    };

    self._load = function() {
        self._await();

        $.get(self._buildUrl(), self._process)
            .error(function(response) {
                self.state('error');
                self._handleError(response);
            });
    };

    self._await = function() {
        self.active = true;
        self.state('await');
        self.templateName('loadingSupplierTemplate');
        $card.show();
    };

    self._innerShow = function(state) {
        self.active = true;
        switch(state) {
            case 'error':
            case 'await':
                $card.show();
                break;
            case 'done':
                $card.show();
                break;
            default:
                throw 'NotSupport';
        }
    };

    self._process = function(html) {
        self.state('done');
        self._parseSupplier(html);
        self.templateName('supplierBodyTemplate');
    };

    self._parseSupplier = function(html) {
        var $html = $($.trim(html)),
            quote = self.quote;

        quote.memberAge = $html.find('.shopimages .cRed').text();
        self._parseSupplierContact($html, quote);
        if(quote.qqArray == null)
            quote.qqArray = [];
    };

    self._parseSupplierContact = function($html, quote) {
        var $items = $html.find('.shopTontTips li'),
            count = $items.length,
            i, $item,
            pos, text, label, content;

        for(i = 0; i < count; i++) {
            $item = $items.eq(i);
            text = $item.text();
            pos = text.indexOf('：');
            if(pos < 0)
                continue;

            label = text.substr(0, pos);
            content = $.trim(text.substring(pos + 1));
            switch(label) {
                case '电话':
                    quote.telephone = content;
                    break;
                case '手机':
                    if(content != 'null')
                        quote.cellphone = content;
                    break;
                case '联系人':
                    quote.contact = content;
                    break;
                case '公司地址':
                    quote.address = content
                    break;
                case '电子市场':
                    if(!quote.address)
                        quote.address = content;
                    break;
                case '在线联系':
                    self._parseQQArray($item, quote);
                    break;
            }
        }
    };

    self._parseQQArray = function($html, quote) {
        var $items = $html.children(),
            count = $items.length,
            tempArray = null,
            qqArray, content,
            i, href, startPos, endPos,
            j;

        quote.qqArray = qqArray = [];
        for(i = 0; i < count; i++) {
            href = $items.eq(i).attr('href');
            startPos = href.indexOf('uin');
            if(startPos < 0)
                continue;

            startPos += 4;
            endPos = href.indexOf('&', startPos);
            if(endPos < 0)
                continue;

            content = href.substring(startPos, endPos);
            if(content.indexOf('，') > 0) {
                tempArray = content.split('，');
            }
            else if(content.indexOf(',') > 0)
            {
                tempArray = content.split(',');
            } else {
                qqArray.push(content);
            }

            if(tempArray != null) {
                for(j = 0; j < tempArray.length; j++) {
                    qqArray.push(tempArray[j]);
                }
                tempArray = null;
            }
        }
    };

    self._handleError = function(response) {
        self.templateName('loadSiblingQuoteFaultedTemplate');
    };

    self._buildUrl = function() {
        return '//s.cecb2b.com/vsearch/corpinfo?id=@supplierId&rantime=@rand'
            .fmt(function($1) { return ($1 == 'rand') ? Math.random() : self.quote[$1]; });
    };

    self.hasContactName = function() {
        var quote = this.quote;
        return self.quote.contact != null && self.quote.contact.length > 0;
    };

    self.hasTelephone = function() {
        return self.quote.telephone != null && self.quote.telephone.length > 0;
    };

    self.hasCellphone = function() {
        return self.quote.cellphone != null && self.quote.cellphone.length > 0;
    };

    self.hasAddress = function() {
        return self.quote.address !=null && self.quote.address.length > 0;
    };

    self.hasQQ = function () {
        return self.quote.qqArray != null && self.quote.qqArray.length > 0;
    };
}

function init(source) {
    var model;

    switch (source.query.site) {
        case "HQEW":
            model = new HqewQuoteViewModel(source);
            break;
        case "ICNET":
            model = new IcnetQuoteViewModel(source);
            break;
        case "DZSC":
            model = new DzscQuoteViewModel(source);
            break;
        case "CECB2B":
            model = new Cecb2bQuoteViewModel(source);
            break;
        default:
            throw 'NotSupport';
    }

    window.m = model;
    ko.applyBindings(model);

    function assignTag(e) {
        var id = parseInt($(e.target).closest('.quote-row').attr('id').substr(5));
        util.assignTag(window.m.quotes[id - 1].supplierName);
    }

    $('#quoteContent')
        .on('click', ' .tag-btn', assignTag)
        .on('click', '.cloud-tags li', assignTag)
        .on('click', '.col10 .qq', function () {
            util.openQQ($(this).attr('data-qq'));
        });

    $('#partNo')
        .on('keyup', function (e) {
            (e.keyCode == 13) && window.m.search();
        });
}