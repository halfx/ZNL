﻿function openChatDialogNew(uid, uguid, status, inquire) {
    var serviceUrl,
        wordRe = /@(\w+)/ig;

    serviceUrl = 'http://hqmim.hqew.com/ajax/services.aspx?uid=@uid&ug=@uguid&type=stype&entuid=@eguid&roid=@roid'
        .replace(wordRe, function ($0, $1) {
            switch ($1) {
                case 'uid':
                    return uid;
                case 'uguid':
                    return uguid;
                case 'stype':
                    return 1;
                case 'entuid':
                    return euid;
                case 'roid':
                    return 0;
                default:
                    return '';
            }
        });

    $.getScript(serviceUrl, function () {
        var defaultUri, uri, code;

        defaultUri = 'hqew://?uid=@uid&uname=@uguid'.replace(wordRe, function ($0, $1) {
            switch ($1) {
                case 'uid':
                    return uid;
                case 'uguid':
                    return uguid;
                default:
                    return '';
            }
        });

        if (HqmServiceObj != null) {
            code = 9;
            if (HqmServiceObj['ResultCode'] != undefined) {
                code = HqmServiceObj['ResultCode'];
            }

            if (code == 0
                && HqmServiceObj['Data']['EntID'] != "0") {
                uri = "hqew://?uid=" + HqmServiceObj['Data']['ServiceID'] + "&uname=" + HqmServiceObj['Data']['Guid']
                    + "&entuid=" + HqmServiceObj['Data']['EntID'] + "&roid=" + HqmServiceObj['Data']['RoID']
                    + (inquire ? '&rfq=' + inquire.ic + '&rfq1=' + encodeURIComponent(inquire.PModel)
                    + '&rfq2=' + encodeURIComponent(inquire.PQuantity) + '&rfq3=' + encodeURIComponent(inquire.S1)
                    + '&rfq4=' + encodeURIComponent(inquire.S2) + '&rfq5=' + encodeURIComponent(inquire.S3)
                    + '&star=' + inquire.star : ''); ;
                util.openHqm(uri);
                return;
            }
        }

        util.openHqm(defaultUri);
        HqmServiceObj = null;
    });
}

function HqmChat(uid, uguid, pguid, inquire) {
    var uri = "hqew://?uid=" + uid + "&uname=" + uguid
        + (inquire ? '&rfq=' + inquire.ic + '&rfq1=' + encodeURIComponent(inquire.PModel)
        + '&rfq2=' + encodeURIComponent(inquire.PQuantity) + '&rfq3=' + encodeURIComponent(inquire.S1)
        + '&rfq4=' + encodeURIComponent(inquire.S2) + '&rfq5=' + encodeURIComponent(inquire.S3)
        + '&star=' + inquire.star : '');
    util.openHqm(uri);
}