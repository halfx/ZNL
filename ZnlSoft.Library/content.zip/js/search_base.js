﻿var userAgent = navigator.userAgent.toLowerCase(),
    ie = /msie/.test(userAgent) && !/opera/.test(userAgent),

util = {
    loadTags: function (names) {
        this.__postData('gettags', JSON.stringify(names),
            supplierTagContoller.done,
            supplierTagContoller.error
         );
    },

    loadQuoteStocks: function (query) {
        this.__postData('getquotestock', JSON.stringify(query),
            quoteStockContoller.done,
            quoteStockContoller.error
        );
    },

    setNoStockTag: function (stock) {
        this.__postData('setnostocktag', JSON.stringify(stock));
    },

    openQuote: function (data) {
        var quote = {
            companyId: data.companyId || null,
            partNo: data.partNo,
            qty: data.qty,
            pack: data.pack,
            batch: data.batch,
            brand: data.brand,
            supplierName: data.supplierName,
            area: data.area,
            description: data.description,
            remark: data.remark,
            contact: data.contact,
            address: data.address,
            telephone: data.telephone,
            cellphone: data.cellphone,
            fax: data.fax,
            qq: data.qq,
            email: data.email,
            site: data.site
        };
        this.__postData('quote', JSON.stringify(quote));
    },

    openQQ: function (qq) {
        this.__postData('openqq', JSON.stringify({ qq: qq }));
    },

    openHqm: function (uri) {
        this.__postData('openhqm', JSON.stringify({ uri: uri }));
    },

    assignTag: function (name) {
        this.__postData('assigntag', JSON.stringify({ name: name }));
    },

    changeQuoteQuery: function (url, q) {
        $.getJSON('/local/api/paging?_=' + (+(new Date())));
        window.location.href = url;
    },

    openUrl: function (url) {
        //window.open(url);
        this.__postData('openurl', JSON.stringify({ url: url }));
    },

    __postData: function (service, data, success, error) {
        $.ajax({
            url: '/local/api/' + service,
            type: 'POST',
            data: data,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            success: success,
            error: error
        });
    }
},

supplierTagContoller = {
    done: function (companies) {
        var i, quotes,
            context = {
                companies: companies,
                diplayedCompanies: [],
                quote: null,
                $root: $('#quoteContent')
            },

            loadTag = function (context, render) {
                var $row,
                    company = findCompany(context);

                context.quote.supplierTag.tags = company.tags;
                context.quote.supplierTag.state = company.state;

                $row = $('#quote' + context.quote.id);
                if (company.state === 1) {
                    $row.find('.cloud-tags').html(render(company.tags)).end()
                        .find('.tag-btn').addClass('active');
                }
            },

            findCompany = function (context) {
                var i, company;
                for (i = context.companies.length; i > 0; i--) {
                    company = context.companies.shift();
                    if (company.name === context.quote.supplierName) {
                        context.diplayedCompanies.push(company);
                        return company;
                    } else {
                        context.companies.push(company);
                    }
                }

                for (i = 0; i < context.diplayedCompanies.length; i++) {
                    company = context.diplayedCompanies[i];
                    if (company.name === context.quote.supplierName) {
                        return company;
                    }
                }
                return null;
            },

            render = function (tags) {
                var i, tag, html = [];
                for (i = 0; i < tags.length; i++) {
                    tag = tags[i];
                    if (tag.isOwn) {
                        html.push('<li class="own" title="' + tag.name + '">' + tag.name + '</li>');
                    } else {
                        html.push('<li class="pub" title="' + tag.name + '">' + tag.name + '</li>');
                    }
                }

                return html.join('');
            };

        if (window.m.quotes && window.m.quotes.length) {
            quotes = window.m.quotes.slice();
            for (i = quotes.length - 1; i > -1; i--) {
                context.quote = quotes.shift();
                loadTag(context, render);
            }
        }

        // if (window.m.quoteStocks && window.m.quoteStocks.length) {
        //     quotes = window.m.quoteStocks.slice()
        //     context.$root = $('#znlStocks')
        //     for (i = quotes.length - 1; i > -1; i--) {
        //         context.quote = quotes.shift();
        //         loadTag(context, render);
        //     }
        // }
    },

    error: function () {
        var quote,
            html = '<a class="tag-btn" title="点评该供应商" href="javascript:;">评</a>';
        for (var i = 0; i < window.m.quotes.length; i++) {
            quote = window.m.quotes[i];
            quote.supplierTag.state = 2;
        }
    }
},

quoteStockContoller = {
    done: function (stocks) {
        var i, supplierNames = [];
        window.window.m.quoteStocks(stocks);
        for (i = 0; i < stocks.length; i++) {
            supplierNames.push(stocks[i].supplierName);
        }
        if (supplierNames.length > 0)
            util.loadTags(supplierNames, true);
    },

    error: function (ret) { }
};

String.prototype.fmt = function (func) {
    return this.replace(/@(\w+)/g, function ($0, $1) { return func($1) });
};