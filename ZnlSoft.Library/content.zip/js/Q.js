﻿//prototype 
Array.prototype.indexOf = function (v) {
    var i = -1;
    while (this[++i]) {
        if (this[i] === v) {
            return i;
        }
    }
    return -1;
};

Array.prototype.remove = function (v) {
    var i = this.indexOf(v);
    if (i > -1) {
        this.splice(i, 1);
    }
    return [i, v];
};

String.prototype.trim = function () {
    return this.replace(/(^\s*)|(\s*$)/g, "");
};

String.prototype.Ltrim = function () {
    return this.replace(/(^\s*)/g, "");
};

String.prototype.Rtrim = function () {
    return this.replace(/(\s*$)/g, "");
};

String.prototype.len = function () {
    return this.replace(/[^\x00-\xff]/g, "**").length;
};

String.prototype.cut = function (l) {
    if (this.len() <= l) {
        return this;
    }

    for (var i = Math.floor(l / 2); i < this.len(); i++) {
        if (this.substr(0, i).len() >= l) {
            return this.substr(0, i);
        }
    }
    return this;
};

String.prototype.encodeHtml = function () {
    return this.replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/ /g, '&nbsp;')
        .replace(/\'/g, '&#39;')
        .replace(/\"/g, '&quot;')
        .replace(/\n/g, '<br />');
};

String.prototype.encodeUrl = function (n) {
    var ret = encodeURIComponent(this.trim());
    if (n == 0) {
        document.all && (ret = encodeURIComponent(ret));
    } else if (n == 2) {
        ret = encodeURIComponent(ret);
    }
    return ret;
};

String.prototype.decodeUrl = function () {
    var ret = decodeURIComponent(this);
    try {
        ret = decodeURIComponent(ret);
    } catch (ex) {
    }
    return ret;
};

//获取节点
function _$() {
    return document.getElementById(arguments[0]);
}

//样式操作
function sClass(e, c) {
    e.className = c;
}

function hClass(e, c) {
    return e.className.match(new RegExp('(\\s|^)' + c + '(\\s|$)'));
}

function aClass(e, c) {
    if (!hClass(e, c)) {
        e.className += ' ' + c;
    }
}

function dClass(e, c) {
    if (hClass(e, c)) {
        e.className = e.className.replace(new RegExp('(\\s|^)' + c + '(\\s|$)'), ' ');
    }
}

function rClass(e, c, n) {
    if (hClass(e, c)) {
        e.className = e.className.replace(new RegExp('(\\s|^)' + c + '(\\s|$)'), ' ' + n);
    }
}

//获取位置、父节点
function getTop(e) {
    var offset = e.offsetTop;
    if (e.offsetParent != null) offset += getTop(e.offsetParent);
    return offset;
}

function getLeft(e) {
    var offset = e.offsetLeft;
    if (e.offsetParent != null) offset += getLeft(e.offsetParent);
    return offset;
}

//遍历
function each(o, t, f) {
    var e = o.getElementsByTagName(t.split('.')[0]);
    for (var i = 0; i < e.length; i++) {
        if (((t.split('.')[1] == 'undefined') ? 1 : e[i].className.indexOf(t.split('.')[1])) > -1) {
            f(e[i]);
        }
    }
}

//插入节点
function insertAfter(newElement, targetElement) {
    var parent = targetElement.parentNode;
    if (parent.lastChild == targetElement) {
        parent.appendChild(newElement);
    } else {
        parent.insertBefore(newElement, targetElement.nextSibling);
    }
}

var base64EncodeChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var base64Encode = new Array(
    -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, 62, -1, -1, -1, 63,
    52, 53, 54, 55, 56, 57, 58, 59,
    60, 61, -1, -1, -1, -1, -1, -1,
    -1, 0, 1, 2, 3, 4, 5, 6,
    7, 8, 9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22,
    23, 24, 25, -1, -1, -1, -1, -1,
    -1, 26, 27, 28, 29, 30, 31, 32,
    33, 34, 35, 36, 37, 38, 39, 40,
    41, 42, 43, 44, 45, 46, 47, 48,
    49, 50, 51, -1, -1, -1, -1, -1
 );

function Base64Encode(str) {
    var reg = /^[a-zA-Z0-9]*$/;
    if (str == null || reg.test(str)) {
        return str
    }
    str = Utf16To8(str);
    var out, i, len;
    var c1, c2, c3;
    len = str.length;
    i = 0;
    out = "";
    while (i < len) {
        c1 = str.charCodeAt(i++) & 0xff;
        if (i == len) {
            out += base64EncodeChars.charAt(c1 >> 2);
            out += base64EncodeChars.charAt((c1 & 0x3) << 4);
            out += "==";
            break
        }
        c2 = str.charCodeAt(i++);
        if (i == len) {
            out += base64EncodeChars.charAt(c1 >> 2);
            out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
            out += base64EncodeChars.charAt((c2 & 0xf) << 2);
            out += "=";
            break
        }
        c3 = str.charCodeAt(i++);
        out += base64EncodeChars.charAt(c1 >> 2);
        out += base64EncodeChars.charAt(((c1 & 0x3) << 4) | ((c2 & 0xf0) >> 4));
        out += base64EncodeChars.charAt(((c2 & 0xf) << 2) | ((c3 & 0xc0) >> 6));
        out += base64EncodeChars.charAt(c3 & 0x3f)
    }
    out = out.replace(/\//g, "@@");
    return "==" + out
}

function Utf16To8(str) {
    var out, i, len, c;
    out = "";
    len = str.length;
    for (i = 0; i < len; i++) {
        c = str.charCodeAt(i);
        if ((c >= 0x0001) && (c <= 0x007f)) {
            out += str.charAt(i)
        } else if (c > 0x07ff) {
            out += String.fromCharCode(0xe0 | ((c >> 12) & 0x0f));
            out += String.fromCharCode(0x80 | ((c >> 6) & 0x3f));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3f))
        } else {
            out += String.fromCharCode(0xc0 | ((c >> 6) & 0x1f));
            out += String.fromCharCode(0x80 | ((c >> 0) & 0x3f))
        }
    }
    return out
}

//Q.js
(function () {
    var Q = window.Q = function (x, pat) {
        return Q.type(x) == 'function' ? Q.ready(x) : new Q.prototype.init(x, pat)
    },
        ff = window.addEventListener ? true : false,
        reHtml = /<|&#?\w+;/;
    Q.prototype = {
        init: function (x, pat) {
            this.elements = [];
            return Q.type(x) === 'string'
                ? (reHtml.test(x) ? this.merge(Q.clean(x))
                : this.selector(x, pat)) : this.merge(x);
        },
        each: function (cb) {
            Q.each(this.e, cb);
            return this;
        },
        merge: function (els) {
            this.pointer = 0;
            this.elements.splice(0, 0, els.length === undefined ? [els] : els);
            this.e = this.elements[this.pointer];
            return this;
        },
        selector: function (x, pat, fir) {
            pat = pat || document;
            pat = pat.length === undefined ? [pat] : pat;
            var ret = [],
                els = function (pat, noe) {
                    var ret = [];
                    Q.each(pat, function () {
                        ret = ret.concat(Q.toArray(this.getElementsByTagName(noe || '*')));
                    });
                    return ret;
                },
                tet = function (els, ate, rep) {
                    var ret = [];
                    Q.each(els, function () {
                        if (Q.reCSS(rep).test(this[ate])) {
                            ret.push(this);
                        }
                    });
                    return ret;
                };
            Q.each(x.split(','), function () {
                ret = ret.concat((function (x, pat, fir) {
                    var ret = [],
                        ary = x.shift().match(/([A-Za-z0-9*]+)?(#|\.)?([\w\-]+)?/);
                    if (ary[2] === '#') {
                        if (fir) {
                            ret = ret.concat(tet(pat, 'id', ary[3]));
                        } else {
                            var elt = document.getElementById(ary[3]);
                            ret = ret.concat(elt ? [elt] : []);
                        }
                    } else if (ary[2] === '.') {
                        if (fir) {
                            ret = ret.concat(tet(ary[1] ? tet(pat, 'nodeName', ary[1].toUpperCase()) : pat, 'className', ary[3]));
                        } else {
                            ret = ret.concat(tet(els(pat, ary[1]), 'className', ary[3]));
                        }
                    } else {
                        if (fir) {
                            ret = ret.concat(tet(pat, 'nodeName', ary[1].toUpperCase()));
                        } else {
                            ret = ret.concat(els(pat, ary[1]));
                        }
                    }
                    return x[0] ? arguments.callee(x, ret) : ret;
                })(fir ? [this] : this.match(/([A-Za-z0-9*]+)?((#|\.)([\w\-]+))|([A-Za-z0-9*]+)((#|\.)([\w\-]+))?/g), pat, fir));
            });
            return this.merge(ret);
        },
        find: function (x) {
            return this.selector(x, this.e);
        },
        filter: function (x) {
            return this.selector(x, this.e, 1);
        },
        end: function () {
            this.e = this.elements[++this.pointer];
            return this;
        },
        eq: function (i) {
            i = i === -1 ? this.e.length - 1 : i;
            return this.merge(this.e[i] ? this.e[i] : []);
        },
        parent: function () {
            var ret = [];
            this.each(function () {
                if (this.parentNode.nodeType === 1 && ret.indexOf(this.parentNode) === -1) {
                    ret.push(this.parentNode);
                }
            });
            return this.merge(ret);
        },
        children: function () {
            var ret = [];
            this.each(function () {
                var i = -1,
                    ths = this.childNodes;
                while (ths[++i]) {
                    if (ths[i].nodeType === 1 && ret.indexOf(ths[i]) === -1) {
                        ret.push(ths[i]);
                    }
                }
            });
            return this.merge(ret);
        },
        sibling: function (sig) {
            var ret = [];
            this.each(function () {
                var ths = this;
                while (ths = ths[sig]) {
                    if (ths.nodeType === 1 && ret.indexOf(ths) === -1) {
                        ret.push(ths);
                    }
                }
            });
            return sig == 'previousSibling' ? ret.reverse() : ret;
        },
        pn: function (sig) {
            var ret = [];
            this.each(function () {
                var ths = this;
                do {
                    ths = ths[sig];
                } while (ths && ths.nodeType !== 1);
                if (ths && ret.indexOf(ths) === -1) {
                    ret.push(ths);
                }
            });
            return ret;
        },
        siblings: function () {
            return this.merge(this.sibling('previousSibling').concat(this.sibling('nextSibling')));
        },
        prevAll: function () {
            return this.merge(this.sibling('previousSibling'));
        },
        nextAll: function () {
            return this.merge(this.sibling('nextSibling'));
        },
        prev: function () {
            return this.merge(this.pn('previousSibling'));
        },
        next: function () {
            return this.merge(this.pn('nextSibling'));
        },
        index: function () {
            return this.sibling('previousSibling').length;
        },
        attr: function (obt) {
            if (Q.type(obt) === 'object') {
                return this.each(function () {
                    for (var n in obt) {
                        this[n] === undefined ? (this.setAttribute && this.setAttribute(n, obt[n])) : this[n] = obt[n];
                    }
                });
            } else {
                return this.e[0] ? (this.e[0][obt] === undefined ? this.e[0].getAttribute(obt) : this.e[0][obt]) : undefined;
            }
        },
        css: function (v, n) {
            if (v === undefined) {
                return this.e[0] ? this.e[0].className : '';
            } else {
                var className, match;
                return this.each(function () {
                    className = ' ' + this.className + ' ';
                    match = function (s) {
                        return ! ~className.indexOf(' ' + s + ' ');
                    };
                    if (n === undefined) {
                        v === '' ? this.className = '' : match(v) && (this.className = (className + v + ' ').trim());
                    } else {
                        if (v === '') {
                            this.className = className = '';
                        } else {
                            className = className.replace(' ' + v + ' ', ' ');
                            this.className = className.trim();
                        }
                        n !== '' && match(n) && (this.className = (className + n + ' ').trim());
                    }
                });
            }
        },
        hasClass: function (v) {
            var ret = false;
            this.each(function () {
                if (Q.reCSS(v).test(this.className)) {
                    ret = true;
                    return false;
                }
            });
            return ret;
        },
        style: function (j) {
            if (typeof j === 'object') {
                return this.each(function () {
                    for (var n in j) {
                        this.style[n] = j[n];
                    }
                });
            } else {
                if (j === 'width') {
                    return this.e[0].clientWidth;
                } else if (j === 'height') {
                    return this.e[0].clientHeight;
                } else {
                    return this.e[0].currentStyle ? this.e[0].currentStyle[j] : document.defaultView.getComputedStyle(this.e[0], null)[j];
                }
            }
        },
        html: function (v) {
            return this.attr(v === undefined ? 'innerHTML' : {
                innerHTML: v
            });
        },
        text: function (v) {
            return this.attr(v === undefined ? (ff ? 'textContent' : 'innerText') : (ff ? {
                'textContent': v
            } : {
                'innerText': v
            }));
        },
        val: function (v) {
            return this.attr(v === undefined ? 'value' : {
                value: v
            });
        },
        width: function (v) {
            return this.style(v === undefined ? 'width' : {
                width: v
            });
        },
        height: function (v) {
            return this.style(v === undefined ? 'height' : {
                height: v
            });
        },
        offset: function () {
            return {
                'top': Q.offset(this.e[0], 'offsetTop'),
                'left': Q.offset(this.e[0], 'offsetLeft'),
                'width': this.e[0].offsetWidth,
                'height': this.e[0].offsetHeight
            };
        },
        position: function (s) {
            return {
                'top': this.e[0].getBoundingClientRect().top + (s ? document.body.scrollTop + document.documentElement.scrollTop : 0),
                'left': this.e[0].getBoundingClientRect().left + (s ? document.body.scrollLeft + document.documentElement.scrollLeft : 0)
            };
        },
        scrollTop: function (v) {
            return this.attr(v === undefined ? 'scrollTop' : {
                scrollTop: v
            });
        },
        scrollLeft: function (v) {
            return this.attr(v === undefined ? 'scrollLeft' : {
                scrollLeft: v
            });
        },
        show: function () {
            return this.style({
                display: 'block'
            });
        },
        hide: function () {
            return this.style({
                display: 'none'
            });
        },
        bind: function (evt, cb) {
            return this.each(function () {
                ff
                    ? this.addEventListener(evt, cb, false)
                    : this.attachEvent('on' + evt, (function (ths, cak) {
                        return ths['ev' + cak] = function () {
                            cak.call(ths, Q.event.fix(window.event));
                        };
                    })(this, cb));
            });
        },
        unbind: function (evt, cb) {
            return this.each(function () {
                ff ? this.removeEventListener(evt, cb, false) : this.detachEvent('on' + evt, this['ev' + cb]);
            });
        },
        on: function (evt, cb) {
            return this.each(function () {
                this['on' + evt] = function (e) {
                    cb.call(this, e || Q.event.fix(window.event));
                };
            });
        }
    };
    Q.each = function (opt, cb) {
        if (opt && opt.length === undefined) {
            for (var n in opt) {
                if (cb.call(opt[n], n) === false) {
                    break;
                }
            }
        } else if (opt && opt.length !== undefined) {
            for (var i = 0; i < opt.length; i++) {
                if (cb.call(opt[i], i) === false) {
                    break;
                }
            }
        }
        return opt;
    };
    Q.event = {
        add: function (evt, cb) {
            ff ? this.addEventListener(evt, cb, false) : this.attachEvent('on' + evt, (function (ths, cak) {
                return ths['ev' + cak] = function () {
                    cak.call(ths, Q.event.fix(window.event));
                };
            })(this, cb));
        },
        remove: function (evt, cb) {
            ff ? this.removeEventListener(evt, cb, false) : this.detachEvent('on' + evt, this['ev' + cb]);
        },
        fix: function (e) {
            var type = e.type.toLowerCase();
            if (type == 'mouseover') {
                e.relatedTarget = e.fromElement;
            } else if (type = 'mouseout') {
                e.relatedTarget = e.toElement;
            }
            e.target = e.srcElement;
            e.pageX = e.clientX;
            e.pageY = e.clientY;
            e.preventDefault = function () {
                this.returnValue = false;
            };
            e.stopPropagation = function () {
                this.cancelBubble = true;
            };
            return e;
        }
    };
    Q.extend = Q.prototype.extend = function () {
        var ret = {};
        if (arguments.length === 1) {
            ret = this;
        }
        Q.each(arguments, function () {
            Q.each(this, function (n) {
                ret[n] = this;
            });
        });
        return ret;
    };
    Q.prototype.extend({
        append: function (x) {
            var f = Q.fragment(Q(x));
            return this.each(function () {
                this.appendChild(f);
            });
        },
        appendTo: function (x) {
            var f = Q.fragment(this);
            (x.e ? x : Q(x)).each(function () {
                this.appendChild(f);
            });
            return this;
        },
        prepend: function (x) {
            var f = Q.fragment(Q(x));
            return this.each(function () {
                this.insertBefore(f, this.firstChild);
            });
        },
        prependTo: function (x) {
            var f = Q.fragment(this);
            (x.e ? x : Q(x)).each(function () {
                this.insertBefore(f, this.firstChild);
            });
            return this;
        },
        before: function (x) {
            var f = Q.fragment(Q(x));
            return this.each(function () {
                this.parentNode.insertBefore(f, this);
            });
        },
        insertBefore: function (x) {
            var f = Q.fragment(this);
            (x.e ? x : Q(x)).each(function () {
                this.parentNode.insertBefore(f, this);
            });
            return this;
        },
        after: function (x) {
            var f = Q.fragment(Q(x));
            return this.each(function () {
                this.parentNode.insertBefore(f, this.nextSibling);
            });
        },
        insertAfter: function (x) {
            var f = Q.fragment(this);
            (x.e ? x : Q(x)).each(function () {
                this.parentNode.insertBefore(f, this.nextSibling);
            });
            return this;
        },
        replaceWith: function (x) {
            var f = Q.fragment(Q(x));
            return this.each(function () {
                this.parentNode.replaceChild(f, this);
            });
        },
        replaceAll: function (x) {
            var f = Q.fragment(this);
            (x.e ? x : Q(x)).each(function () {
                this.parentNode.replaceChild(f, this);
            });
            return this;
        },
        empty: function () {
            return this.each(function () {
                while (this.firstChild) {
                    this.removeChild(this.firstChild);
                }
            });
        },
        remove: function () {
            return this.each(function () {
                this.parentNode.removeChild(this);
            });
        },
        clone: function () {
            var ret = [];
            this.each(function () {
                ret.push(this.cloneNode(true));
            });
            return this.merge(ret);
        }
    });
    Q.extend({
        ready: function (cak) {
            ff ? document.addEventListener('DOMContentLoaded', cak, false) : (function () {
                try {
                    document.documentElement.doScroll('left');
                } catch (e) {
                    setTimeout(arguments.callee, 1);
                    return;
                }
                cak();
            })();
        },
        type: function (obt) {
            return (obt === null ? String(obt) : Object.prototype.toString.call(obt).slice(8, -1)).toLowerCase();
        },
        toArray: function (obt) {
            try {
                return [].slice.call(obt);
            } catch (e) {
                var ret = [];
                Q.each(obt, function () {
                    ret.push(this);
                });
                return ret;
            }
        },
        toStr: function (obt) {
            switch (Q.type(obt)) {
                case 'unknown':
                    return undefined;
                case 'regexp':
                    return obt.toString();
                case 'number':
                    return isFinite(obt) ? obt.toString() : 'null';
                case 'string':
                    return '"' + obt.replace(/(\\|\")/g, "\\$1").replace(/\n|\r|\t/g, function () {
                        var a = arguments[0];
                        return (a == '\n') ? '\\n' : (a == '\r') ? '\\r' : (a == '\t') ? '\\t' : "";
                    }) + '"';
                case 'object':
                    if (obt === null) {
                        return 'null';
                    }
                    var ret = [];
                    for (var n in obt) {
                        if (obt[n] != null) {
                            var value = Q.toStr(obt[n]);
                            if (value !== undefined) {
                                ret.push(Q.toStr(n) + ':' + value);
                            }
                        } else {
                            ret.push(n + ':null');
                        }
                    }
                    return '{' + ret.join(',') + '}';
                case 'array':
                    var ret = [];
                    for (var i = 0; i < obt.length; i++) {
                        var value = Q.toStr(obt[i]);
                        if (value !== undefined) {
                            ret.push(value);
                        }
                    }
                    return '[' + ret.join(',') + ']';
            }
        },
        reCSS: function (stg) {
            return RegExp('(^|\\s)' + stg + '(\\s|$)');
        },
        offset: function (t, f) {
            var ret = t[f];
            t.offsetParent != null && (ret += arguments.callee(t.offsetParent, f));
            return ret;
        },
        contains: function (p, c, s) {
            var tmp = p.contains ? p != c && p.contains(c) : !!(p.compareDocumentPosition(c) & 16);
            return s ? tmp || p == c : tmp;
        },
        eval: function (stg) {
            return eval('(' + stg + ')');
        },
        clean: function (x) {
            var div = document.createElement('div');
            div.innerHTML = x;
            return Q.toArray(div.childNodes);
        },
        fragment: function (x) {
            frt = document.createDocumentFragment();
            x.each(function () {
                frt.appendChild(this);
            });
            return frt;
        },
        cookie: function (name, value, expires) {
            if (value) {
                var duration = new Date();
                duration.setDate(duration.getDate() + expires);
                document.cookie = name + '=' + encodeURIComponent(value) + ';path=/' + (expires ? ';expires=' + duration.toGMTString() : '');
                return value;
            } else {
                var arr = document.cookie.match(new RegExp('(^| )' + name + '=([^;]*)(;|$)'));
                return arr != null ? decodeURIComponent(arr[2]) : '';
            }
        },
        request: function (name) {
            var ret = window.location.search.substr(1).match(new RegExp("(^|&)" + name + "=([^&]*)(&|$)"));
            return ret != null ? ret[2].decodeUrl() : '';
        },
        js: function (obt) {
            var hed = document.getElementsByTagName('head')[0],
                sct = null,
                com = function () {
                    obt.success && obt.success();
                    sct.loaded = true;
                    obt.cache !== undefined && hed.removeChild(sct);
                };
            obt.cache === undefined && Q('head script').each(function () {
                if (this.src == (obt.url.indexOf('http://') > -1 ? obt.url : 'http://' + location.host + obt.url)) {
                    sct = this;
                    return false;
                }
            });
            if (!sct) {
                sct = document.createElement('script'),
                    sct.type = 'text/javascript';
                sct.src = obt.url + (obt.cache === false ? (obt.url.indexOf('?') > -1 ? '&_=' : '?_=') + new Date().getTime() : '');
                sct.charset = obt.charset || 'utf-8';
            }
            sct.loaded ? com() : (ff ? sct.addEventListener('load', com, false) : sct.attachEvent('onreadystatechange', function () {
                /loaded|complete/.test(sct.readyState) && com();
            }));
            hed.appendChild(sct);
        },
        ajax: function (obt) {
            var xhr,
                msg = Q('<div style="position:absolute; top:100px; right:100px; padding:10px 20px; border:#ccc solid 1px; color:#666; background:#f3f3f3; display:none;"></div>');
            if (obt.start) {
                obt.start();
            } else {
                //msg.appendTo('body').text('Loading').show()
            }
            try {
                xhr = new XMLHttpRequest();
            } catch (e) {
                try {
                    xhr = new ActiveXObject('Microsoft.XMLHTTP');
                } catch (e) {
                    //msg.appendTo('body').text('Can Not Create XMLHTTP Object').show();
                    return false;
                }
            }
            xhr.open(obt.method || 'post', obt.url, obt.async || true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4) {
                    if (xhr.status === 200) {
                        if (obt.stop) {
                            obt.stop();
                        } else {
                            //msg.appendTo('body').text('Success').show();
                            setTimeout(function () {
                                msg.remove();
                            }, 5000);
                        }
                        switch (obt.type) {
                            case 'xml':
                                obt.success(xhr.responseXML);
                                break;
                            case 'text':
                                obt.success(xhr.responseText);
                                break;
                            case 'json':
                                obt.success(Q.eval(xhr.responseText));
                                break;
                            case 'script':
                                Q.eval(xhr.responseText);
                                obt.success();
                                break;
                            default:
                                obt.success(xhr.responseText);
                                break;
                        }
                    } else {
                        if (obt.error) {
                            obt.error(xhr.statusText);
                        } else {
                            //msg.appendTo('body').text(xhr.statusText).show()
                        }
                    }
                }
            };
            xhr.send(obt.param || '');
        }
    });

    Q.each(
        ['focus', 'click', 'dblclick', 'change', 'select', 'submit',
         'keydown', 'keypress', 'keyup',
         'mousedown', 'mouseup', 'mousemove', 'mouseover', 'mouseout',
         'mouseenter', 'mouseleave', 'blur', 'error', 'resize', 'scroll', 'load', 'unload'],
        function () {
            var self = this;
            Q.prototype[self] = function (cb) {
                return this.bind(self, cb);
            };
        });

    Q.prototype.init.prototype = Q.prototype;
})();

// hover layer
Q.prototype.hoverLayer = function (opt) {
    opt.tag = Q(opt.tag);
    Q(opt.tag.e).parent().e.length == 0 && opt.tag.appendTo('body');
    Q(opt.tag.e).children().eq(0).on('click', function () {
        opt.tag.hide();
    });
    this.on('mouseover', function () {
        var self = Q(this),
            position = self.position(true);
        opt.tag.show().style({
            'top': position.top + (opt.top ? opt.top : self.offset().height - 5) + 'px',
            'left': position.left + (opt.left ? opt.left : 0) + 'px'
        });
        opt.callback && opt.callback.call(this);
    }).on('mouseout', function () {
        opt.tag.hide();
    });
    opt.tag.on('mouseover', function () {
        opt.tag.show();
    }).on('mouseout', function (e) {
        if (Q.contains(this, e.relatedTarget, true)) {
            return;
        }
        opt.tag.hide();
    });
    return this;
};